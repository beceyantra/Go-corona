import 'package:cloud_firestore/cloud_firestore.dart';

class RequestedBedDetailModel {
  final String name;
  final String srfId;
  final String number;
  final String testedDate;
  final String age;
  final String aadhar;
  final String dateAndTime;
  final double latitude;
  final double longitude;
  final String emailid;
  final String acceptedTime;
  final String dischargeTime;

  RequestedBedDetailModel({
    this.name,
    this.srfId,
    this.number,
    this.testedDate,
    this.age,
    this.aadhar,
    this.dateAndTime,
    this.latitude,
    this.longitude,
    this.emailid,
    this.acceptedTime,
    this.dischargeTime,
  });
}
