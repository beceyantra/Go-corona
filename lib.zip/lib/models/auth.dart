import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';

class FireBase {
  static FirebaseAuth auth = FirebaseAuth.instance;
  static var authUser = FirebaseAuth.instance.currentUser;
  static instantiate() {}
}

class AuthModel with ChangeNotifier {
  Future<String> userNumber() async {
    FirebaseUser user = await FirebaseAuth.instance.currentUser();
    return user.phoneNumber;
  }
}
