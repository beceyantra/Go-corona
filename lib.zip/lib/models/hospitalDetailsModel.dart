

class HospitalDetailModel{
  final String username;
  final bool beds;
  final bool icu;
  final bool oxygen;
  final bool ventilator;
  final String id;
  final bool vaccine;
  final String ownername;
  final String emailid;
  final String address;
  final String number;
  HospitalDetailModel({
    this.username,
    this.beds,
    this.icu,
    this.oxygen,
    this.ventilator,
    this.id,
    this.vaccine,
    this.address,
    this.emailid,
    this.ownername,
    this.number,
  });
}