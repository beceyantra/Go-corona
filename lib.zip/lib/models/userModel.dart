class UserModel{
  final String username;
  final String email;
  final String number;
  final String createdAt;
  final String gender;
  final String age;
  final String bloodgroup;
  UserModel({
    this.username,
    this.age,
    this.bloodgroup,
    this.createdAt,
    this.email,
    this.gender,
    this.number,
  });
}