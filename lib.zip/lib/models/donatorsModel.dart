
import 'package:cloud_firestore/cloud_firestore.dart';

class DonatorsModel{
  final String aadharNumber;
  final String age;
  final String bloodgroup;
  final String latitude;
  final String longitude;
  final Timestamp plasmaCreatedAt;
  final String number;
  final String name;
  final String srfId;
  final String testedDate;
  final String id;
  final double dist;

  DonatorsModel({
    this.aadharNumber,
    this.age,
    this.bloodgroup,
    this.latitude,
    this.longitude,
    this.name,
    this.number,
    this.plasmaCreatedAt,
    this.srfId,
    this.testedDate,
    this.id,
    this.dist,
  });
}