import 'dart:async';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_corona/Screens/admin_model.dart';
import 'package:go_corona/Screens/auth.dart';
import 'package:go_corona/Screens/home_screen.dart';
import 'package:go_corona/Screens/hospital_model.dart';
import 'package:go_corona/Screens/otp_screen.dart';
import 'package:go_corona/Screens/registration.dart';
import 'package:go_corona/provider/phone_auth.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Directory document = await getApplicationDocumentsDirectory();
  Hive.init(document.path);
  await Hive.openBox<String>("loginData");
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => PhoneAuthDataProvider(),
        ),
      ],
      child: MaterialApp(
        title: 'Go Corona',
        routes: {
          '/authscreen': (context) => AuthScreen(),
          '/otpscreen': (context) => OTPScreen(),
          '/homepage': (context) => HomeScreen(),
          '/hospiatl': (context) => HospitalModel(),
          '/register': (context) => Registration(),
          '/admin':(context) => AdminModel(),
        },
        debugShowCheckedModeBanner: false,
        home: SplashScreen(),
      ),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  String number;
  Box<String> logindata;

  // Box<String> logindata;
  @override
  void initState() {
    super.initState();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
    Timer(Duration(seconds: 3), () => Open());
  }

  // ignore: non_constant_identifier_names
  void Open() async {
    number == null || number == ''
        ? Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (BuildContext context) => AuthScreen()))
        : await Firestore.instance
            .collection("Users")
            .document(number)
            .get()
            .then((value) => {
                  if (value.exists)
                    {
                      if(value.data['role']=="hospital"){
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => HospitalModel()))
                      }else if(value.data['role']=="user"){
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => HomeScreen()))
                      }else if(value.data['role']=="admin"){
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) => AdminModel()))
                      }
                      
                    }
                  else
                    {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  Registration()))
                    }
                });
  }

  // // ignore: non_constant_identifier_names
  // void Open() async {
  //   number == null || number == ''
  //       ? Navigator.pushReplacement(context,
  //           MaterialPageRoute(builder: (BuildContext context) => Login()))
  //       : await Firestore.instance
  //           .collection("Users")
  //           .document(number)
  //           .get()
  //           .then((value) {
  //           if (value.exists) {
  //             if (value.data['role'] == "alumni") {
  //               if (value.data['status'] != 'accepted') {
  //                 Navigator.pushReplacement(
  //                     context,
  //                     MaterialPageRoute(
  //                         builder: (BuildContext context) => Login()));
  //               } else {
  //                 Navigator.pushReplacement(
  //                     context,
  //                     MaterialPageRoute(
  //                         builder: (BuildContext context) => HomePage()));
  //               }
  //             } else {
  //               Navigator.pushReplacement(
  //                   context,
  //                   MaterialPageRoute(
  //                       builder: (BuildContext context) => HomePageAdmin()));
  //             }
  //           } else {
  //             Navigator.pushReplacement(
  //                 context,
  //                 MaterialPageRoute(
  //                     builder: (BuildContext context) => Login()));
  //           }
  //         });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(color: Colors.white),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Expanded(
                flex: 6,
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Container(
                        height: MediaQuery.of(context).size.height * 0.5,
                        width: MediaQuery.of(context).size.width * 0.9,
                        decoration: BoxDecoration(
                          color: Colors.white,
                        ),
                        child: Image.asset("assets/images/gocorona.jpg")
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 5),
                      ),
                      Flexible(
                        child: Text(
                          "Go Corona",
                          style: TextStyle(color: Colors.black, fontSize: 28.0),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}
