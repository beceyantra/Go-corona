import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoder/geocoder.dart' as GeoCoder;
import 'package:go_corona/models/hospitalDetailsModel.dart';
import 'book_bed_form.dart';
import 'dart:math' as Math;

class Hospitallist extends StatefulWidget {
  @override
  _HospitallistState createState() => _HospitallistState();
}

class _HospitallistState extends State<Hospitallist> {
  final List<String> img = <String>[
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg',
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg',
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg',
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg'
  ];

  var dist;

  double latitude = 00.00000;
  double longitude = 00.00000;
  var coordinates;

  _getCurrentloc() async {
    Position geolocation = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    coordinates =
        new GeoCoder.Coordinates(geolocation.latitude, geolocation.longitude);
    latitude = geolocation.latitude;
    longitude = geolocation.longitude;
  }

  double getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2 - lat1); // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(lat1)) *
            Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in km
    return d;
  }

  double deg2rad(deg) {
    return deg * (Math.pi / 180);
  }

  @override
  Widget build(BuildContext context) {
    // style
    _getCurrentloc();
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Hospital List"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: StreamBuilder(
                stream: Firestore.instance
                    .collection("Users")
                    .where("role", isEqualTo: "hospital")
                    .snapshots(),
                builder: (context, snapShot) {
                  if (snapShot.connectionState == ConnectionState.waiting)
                    return Center(child: CircularProgressIndicator());
                  else {
                    if (snapShot.hasData) {
                      final docSnap = snapShot.data.documents;
                      dist = getDistanceFromLatLonInKm(
                          latitude, longitude, 15.5454, 70.5454);
                      return docSnap.length <= 0
                          ? Center(child: Text("No Hospital Available"))
                          : ListView.builder(
                              padding: const EdgeInsets.all(8),
                              itemCount: docSnap.length,
                              itemBuilder: (BuildContext context, int index) {
                                return dist > 50
                                    ? Container()
                                    : Container(
                                        height: 80,
                                        margin: EdgeInsets.only(top: 5),
                                        child: Card(
                                          shadowColor: Colors.blueAccent,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20)),
                                          elevation: 4,
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: <Widget>[
                                              TextButton(
                                                onPressed: () {},
                                                child: CircleAvatar(
                                                  radius: 32,
                                                  backgroundImage: AssetImage(
                                                      'assets/images/${img[index]}'),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 16,
                                              ),
                                              Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    docSnap[index]['username'],
                                                    style: TextStyle(
                                                        fontFamily:
                                                            "Montserrat Medium",
                                                        color: Colors.black,
                                                        fontSize: 15),
                                                  ),
                                                  Text(
                                                    'Distance : $dist KM',
                                                    style: TextStyle(
                                                        fontFamily:
                                                            "Montserrat Medium",
                                                        color: Colors.green,
                                                        fontSize: 12),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(
                                                width: 16,
                                              ),
                                              IconButton(
                                                icon: Icon(
                                                    Icons.play_arrow_outlined,
                                                    color: Colors.black),
                                                onPressed: () {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                      builder: (context) =>
                                                          Hdetails(
                                                              hospitalDetailModel:
                                                                  HospitalDetailModel(
                                                        id: docSnap[index]
                                                            .documentID,
                                                        username: docSnap[index]
                                                            ['username'],
                                                        icu: docSnap[index]
                                                            ['icu'],
                                                        beds: docSnap[index]
                                                            ['beds'],
                                                        ventilator:
                                                            docSnap[index]
                                                                ['ventilator'],
                                                        oxygen: docSnap[index]
                                                            ['oxygen'],
                                                        vaccine: docSnap[index]
                                                            ['vaccine'],
                                                      )),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                              });
                    } else {
                      return Center(child: Text("No Posts Available"));
                    }
                  }
                })));
  }
}

class Hdetails extends StatelessWidget {
  final HospitalDetailModel hospitalDetailModel;
  Hdetails({this.hospitalDetailModel});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Hospital Datails"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 14,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Container(
              height: 700,
              width: 500,
              margin: EdgeInsets.only(top: 5, left: 10, right: 10, bottom: 10),
              child: Card(
                shadowColor: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                elevation: 4,
                child: ListView(children: <Widget>[
                  Container(
                      padding: EdgeInsets.only(top: 20, bottom: 20),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            CircleAvatar(
                              radius: 100,
                              backgroundImage:
                                  AssetImage('assets/images/hospital1.jpg'),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              '${hospitalDetailModel.username}',
                              style: TextStyle(
                                  fontFamily: 'Hind',
                                  color: Colors.black,
                                  fontSize: 16),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(
                              color: Colors.black,
                            ),
                            Container(
                              padding: EdgeInsets.only(top: 10),
                              child: Text(
                                'Availables',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    decoration: TextDecoration.underline,
                                    fontFamily: 'Hind',
                                    color: Colors.orange,
                                    fontSize: 20),
                              ),
                            ),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 20, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.king_bed),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Bed: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      hospitalDetailModel.beds
                                          ? "Available"
                                          : "Not-Available",
                                      style: hospitalDetailModel.beds
                                          ? TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.green,
                                              fontSize: 15)
                                          : TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.red,
                                              fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.picture_in_picture),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'ICU: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      hospitalDetailModel.icu
                                          ? "Available"
                                          : "Not-Available",
                                      style: hospitalDetailModel.icu
                                          ? TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.green,
                                              fontSize: 15)
                                          : TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.red,
                                              fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.outbox),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Oxygen: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      hospitalDetailModel.oxygen
                                          ? "Available"
                                          : "Not-Available",
                                      style: hospitalDetailModel.oxygen
                                          ? TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.green,
                                              fontSize: 15)
                                          : TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.red,
                                              fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.vignette_rounded),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Ventilator: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      hospitalDetailModel.ventilator
                                          ? "Available"
                                          : "Not-Available",
                                      style: hospitalDetailModel.ventilator
                                          ? TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.green,
                                              fontSize: 15)
                                          : TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.red,
                                              fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.vignette_rounded),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Vaccine: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      hospitalDetailModel.vaccine
                                          ? "Available"
                                          : "Not-Available",
                                      style: hospitalDetailModel.vaccine
                                          ? TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.green,
                                              fontSize: 15)
                                          : TextStyle(
                                              fontFamily: 'Hind',
                                              color: Colors.red,
                                              fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 25, left: 20, right: 20, bottom: 20),
                                child: Material(
                                  elevation: 5,
                                  color: Colors.lightBlue,
                                  borderRadius: BorderRadius.circular(32.0),
                                  child: MaterialButton(
                                    onPressed: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                Book_bed_form()),
                                      );
                                    },
                                    minWidth: 150.0,
                                    height: 45.0,
                                    child: Text(
                                      "BOOK BED",
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16.0,
                                          fontFamily: 'Hind'),
                                    ),
                                  ),
                                )),
                          ])),
                ]),
              ),
            )));
  }
}
