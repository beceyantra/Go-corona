import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_corona/models/userModel.dart';
import 'package:intl/intl.dart';

class Userlist extends StatefulWidget {
  @override
  _UserlistState createState() => _UserlistState();
}

class _UserlistState extends State<Userlist> {
  @override
  Widget build(BuildContext context) {
    // style

    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("User List"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: StreamBuilder(
                stream: Firestore.instance
                    .collection("Users")
                    .where("role", isEqualTo: "user")
                    .snapshots(),
                builder: (context, snapShot) {
                  if (snapShot.connectionState == ConnectionState.waiting)
                    return Center(child: CircularProgressIndicator());
                  else {
                    if (snapShot.hasData) {
                      final docSnap = snapShot.data.documents;
                      return docSnap.length <= 0
                          ? Center(child: Text("No User Available"))
                          : ListView.builder(
                              padding: const EdgeInsets.all(8),
                              itemCount: docSnap.length,
                              itemBuilder: (BuildContext context, int index) {
                                var createdDate = DateTime.parse(docSnap[index]
                                        ['createdAt']
                                    .toDate()
                                    .toString());
                                return Container(
                                  height: 80,
                                  margin: EdgeInsets.only(top: 5),
                                  child: Card(
                                    shadowColor: Colors.blueAccent,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(20)),
                                    elevation: 4,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        TextButton(
                                          onPressed: () {},
                                          child: CircleAvatar(
                                            radius: 32,
                                            backgroundImage: AssetImage(
                                                'assets/images/person_icon.jpg'),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16,
                                        ),
                                        Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              ' ${docSnap[index]['username']}',
                                              style: TextStyle(
                                                  fontFamily:
                                                      "Montserrat Medium",
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          width: 40,
                                        ),
                                        IconButton(
                                          icon: Icon(Icons.play_arrow_outlined,
                                              color: Colors.black),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => Hdetails(
                                                  userModel: UserModel(
                                                      email: docSnap[index]
                                                          ['emailid'],
                                                      bloodgroup: docSnap[index]
                                                          ['bloodgroup'],
                                                      username: docSnap[index]
                                                          ['username'],
                                                      number: docSnap[index]
                                                          ['number'],
                                                      gender: docSnap[index]
                                                          ['gender'],
                                                      age: docSnap[index]
                                                          ['age'],
                                                      createdAt:
                                                          '${DateFormat('d/MM/y hh:mm a').format(createdDate)}'),
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              });
                    }
                  }
                })));
  }
}

class Hdetails extends StatelessWidget {
  final UserModel userModel;
  Hdetails({this.userModel});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Datails"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 14,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Container(
              height: 700,
              width: 500,
              margin: EdgeInsets.only(top: 5, left: 10, right: 10, bottom: 10),
              child: Card(
                shadowColor: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                elevation: 4,
                child: ListView(children: <Widget>[
                  Container(
                      padding: EdgeInsets.only(top: 20, bottom: 20),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            CircleAvatar(
                              radius: 100,
                              backgroundImage:
                                  AssetImage('assets/images/person_icon.jpg'),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(
                              color: Colors.black,
                            ),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 20, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.person),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Name: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      '${userModel.username}',
                                      style: TextStyle(
                                          fontFamily: 'Hind', fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: const <Widget>[
                                    Icon(Icons.home),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Addrees: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      'bagalkot',
                                      style: TextStyle(
                                          fontFamily: 'Hind', fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.phone_android),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Phone Number: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      '${userModel.number}',
                                      style: TextStyle(
                                          fontFamily: 'Hind', fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(children: <Widget>[
                                  Icon(Icons.email, color: Colors.black),
                                  Text(
                                    ' Email-Id :',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      child: Expanded(
                                          child: SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Text(
                                                ' ${userModel.email}',
                                                style: TextStyle(
                                                    fontFamily: 'Hind',
                                                    color: Colors.black,
                                                    fontSize: 16),
                                              ))))
                                ])),
                          ])),
                ]),
              ),
            )));
  }
}
