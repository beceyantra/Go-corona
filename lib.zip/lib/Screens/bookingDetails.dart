import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class BookingDeatils extends StatefulWidget {
  @override
  _BookingDeatilsState createState() => _BookingDeatilsState();
}

class _BookingDeatilsState extends State<BookingDeatils> {
  void showInSnackBar(String value, BuildContext context) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  Box<String> logindata;
  String number, emailid;

  @override
  void initState() {
    super.initState();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
    emailid = logindata.get("emailid");
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
        stream: Firestore.instance
            .collection("bedBooking")
            .document(number)
            .snapshots(),
        builder: (context, snapshot) {
          var createdDate = DateTime.parse(
              snapshot.data['bookingCreatedAt'].toDate().toString());
          return !snapshot.hasData
              ? Container(
                  child: Center(
                    child: Text("No booking data available"),
                  ),
                )
              : MaterialApp(
                  theme: ThemeData(primarySwatch: Colors.lightBlue),
                  home: Scaffold(
                    appBar: AppBar(
                      leading: IconButton(
                        icon: Icon(Icons.arrow_back, color: Colors.black),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      title: Text("Details"),
                      titleTextStyle: TextStyle(
                          fontFamily: "Montserrat Regular",
                          fontSize: 14,
                          color: Colors.blue),
                      flexibleSpace: Image(
                        image: AssetImage('assets/images/top_header.png'),
                        fit: BoxFit.cover,
                      ),
                      backgroundColor: Colors.transparent,
                      centerTitle: true,
                    ),
                    body: Container(
                      height: 700,
                      width: 500,
                      margin: EdgeInsets.only(
                          top: 5, left: 10, right: 10, bottom: 10),
                      child: ListView(children: <Widget>[
                        Container(
                          padding: EdgeInsets.only(top: 20, bottom: 20),
                          child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(children: <Widget>[
                                      Icon(Icons.person,
                                          color: Colors.blueGrey),
                                      Text(
                                        ' Name : ${snapshot.data['name']}',
                                        style: TextStyle(
                                            fontFamily: 'Hind',
                                            color: Colors.black,
                                            fontSize: 16),
                                      ),
                                    ])),
                                SizedBox(height: 10),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.location_on,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Bagalkot',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.email,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Email-Id :',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                          Container(
                                              child: Expanded(
                                                  child: SingleChildScrollView(
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      child: Text(
                                                        ' ${snapshot.data['emailid']}',
                                                        style: TextStyle(
                                                            fontFamily: 'Hind',
                                                            color: Colors.black,
                                                            fontSize: 16),
                                                      ))))
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.phone,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Phone Number : ${snapshot.data['number']}',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.ac_unit,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Aadhar Card Number : ',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                          Container(
                                              child: Expanded(
                                                  child: SingleChildScrollView(
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      child: Text(
                                                        ' ${snapshot.data['aadharNumber']}',
                                                        style: TextStyle(
                                                            fontFamily: 'Hind',
                                                            color: Colors.black,
                                                            fontSize: 16),
                                                      ))))
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.smart_button,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' SRF ID : ',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                          Container(
                                              child: Expanded(
                                                  child: SingleChildScrollView(
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      child: Text(
                                                        ' SRF-${snapshot.data['srfId']}',
                                                        style: TextStyle(
                                                            fontFamily: 'Hind',
                                                            color: Colors.black,
                                                            fontSize: 16),
                                                      ))))
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.date_range,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Tested Date : ${snapshot.data['testedDate']}',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.date_range,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Book Requested Date : ${DateFormat('d/MM/y hh:mm a').format(createdDate)}',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                        ])),
                                SizedBox(height: 12),
                                Container(
                                    height: 50,
                                    padding: EdgeInsets.all(5),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.white,
                                            offset: Offset(2.0, 2.0),
                                          )
                                        ]),
                                    child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Icon(Icons.date_range,
                                              color: Colors.blueGrey),
                                          Text(
                                            ' Status : ${snapshot.data['status']}',
                                            style: TextStyle(
                                                fontFamily: 'Hind',
                                                color: Colors.black,
                                                fontSize: 16),
                                          ),
                                        ])),
                                SizedBox(height: 12),
                              ]),
                        )
                      ]),
                    ),
                  ));
        });
  }
}
