import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';

import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hive/hive.dart';

import 'home_screen.dart';
 
 
// ignore: camel_case_types
class Addhospitalinfo extends StatefulWidget {
  @override
  AddhospitalinfoState createState() => AddhospitalinfoState();
  }
  

// ignore: camel_case_types
class AddhospitalinfoState extends State<Addhospitalinfo> {
  Position _currentPosition;
  String _currentAddress;     
   String _setDate; 
  final _hname = TextEditingController();
  final _oname = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _location = TextEditingController();

  bool _isLoading = false;

  
  double latitude = 00.00000;
  double longitude = 00.00000;
  var coordinates;


  

   final _formFieldKeyhname = GlobalKey<FormFieldState>();
   final _formFieldKeyoname = GlobalKey<FormFieldState>();
   final _formFieldKeyphone = GlobalKey<FormFieldState>();
   final _formFieldKeyemail = GlobalKey<FormFieldState>();
   final _formFieldKeylocation = GlobalKey<FormFieldState>();
   
  
  DateTime currentDate = DateTime.now();
  Box<String> logindata;
  String number;
  String emailid;
  
  @override
  void initState() {
    // ignore: todo
    // TODO: implement initState
   _getCurrentLocation();
   super.initState();
       logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
    emailid = logindata.get("emailid");

    _email.text = emailid;
    _phone.text = number;
    
  }
  
 
  


 

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
            theme: ThemeData(primarySwatch: Colors.lightBlue),
                home: Scaffold(
                  appBar: AppBar(
                    leading: IconButton(
                  icon: Icon(Icons.arrow_back, color: Colors.black),
                  onPressed: () => Navigator.of(context).pop(),
                ),                          
                          title: Text("Add Hospital"),
                          titleTextStyle: TextStyle(fontFamily: "Montserrat Regular",
                                fontSize: 14,
                                color: Colors.blue),
                          flexibleSpace: Image(
                            image: AssetImage('assets/images/top_header.png'),
                            fit: BoxFit.cover,
                          ),
                  backgroundColor: Colors.transparent,
                          centerTitle: true,
                        ),
        body:Form(           
            child: ListView(
              children: <Widget>[
           Container(
                  padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                  child: TextFormField(
                    key: _formFieldKeyhname,
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Hospital Name';
                        }
                        return null;
                      },
                    controller: _hname,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                      Icons.local_hospital,
                      color: Colors.brown,
                       ),
                      border: OutlineInputBorder(),
                      labelText: 'Hospital Name',
                    ),
                  ),
                ),
                 Container(
                  padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                  child:  TextFormField(
                    key: _formFieldKeyoname,
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Owner Name';
                        }
                        return null;
                      },
                     controller: _oname,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                      Icons.person,
                      color: Colors.brown,
                       ),
                      border: OutlineInputBorder(),
                      labelText: 'Owner Name',
                    ),
                  ),
                ),
                 Container(
                  padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                  child:TextFormField(
                    key: _formFieldKeyphone,
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Phone Number';
                        }
                        return null;
                      },
                    controller: _phone,
                    keyboardType: TextInputType.number,
                    enabled: false,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                      Icons.phone_android,
                      color: Colors.brown,
                       ),
                      border: OutlineInputBorder(),
                      labelText: 'Phone Number',
                    ),
                  ),
                ),
                  Container(
                  padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                  child:TextFormField(
                    key: _formFieldKeyemail,
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Email Id';
                        }
                        return null;
                      },
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                      Icons.email,
                      color: Colors.brown,
                       ),
                      border: OutlineInputBorder(),
                      labelText: 'Email Id',
                      enabled: false,
                    ),
                  ),
                ),
                
              


                 Container(
                  padding: EdgeInsets.only(top: 20,left: 20,right: 20),
                  child: TextFormField(
                    key: _formFieldKeylocation,
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter Location';
                        }
                        return null;
                      },
                    controller: _location,
                    keyboardType: TextInputType.text,
                    decoration: InputDecoration(
                     
                      prefixIcon: Icon(
                      Icons.location_on,
                      color: Colors.brown,
                       ),
                       
                   
                     
                   
                      border: OutlineInputBorder(),
                      labelText: 'Location', 
                      
                    ),
                  
                  ),
                             

                ),
               
               

                       


              Container(
                width: 10,
                  padding: EdgeInsets.only(top: 20,left: 20,right: 20,bottom: 20),
              child: Material(                
                elevation: 5,
                color: Colors.lightBlue,
                borderRadius: BorderRadius.circular(32.0),
                child: MaterialButton(
                  onPressed: () {
//                  Navigator.push(
//                    context,
//                    MaterialPageRoute(builder: (context) => MyLoginPage()),
//                  );
                  if (_formFieldKeyhname.currentState.validate() && _formFieldKeyoname.currentState.validate() && _formFieldKeyphone.currentState.validate() && _formFieldKeyemail.currentState.validate() && _formFieldKeylocation.currentState.validate()  ) {
                    
                    _saveform();

                  }         
                                        
                  },
                  minWidth: 30.0,
                  height: 45.0,
                  child: Text(
                    "Add Hospital",
                    style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20.0),
                  ),
                ),
              )
              )

                                                              
            ],
          )
        )
        )
        );
  }

 

   _saveform()async{
      _isLoading = true;
    try {
      await Firestore.instance.collection("Users").document(number).updateData({
        'longitude': longitude,
        'latitude': latitude,
        'ownername':_oname.text,
        'username':_hname.text,
        'status':"requested",
        'number':number,
        'location':_location.text
      }).then((value) => {
            _isLoading = false,
            showInSnackBar("Hospital Request send to admin wait for confirmation"),
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => HomeScreen(),
                )),
          });
    } on PlatformException catch (err) {
      var message = 'Error Please try again.. $err';
      _isLoading = false;

      if (err.message != null) {
        message = err.message;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Theme.of(context).errorColor,
        ),
      );
      setState(() {
        _isLoading = false;
      });
    } catch (err) {
      print(err);
      setState(() {
        _isLoading = false;
      });
    }

   }

   
  void showInSnackBar(String value) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }


   _getCurrentLocation() {
    Geolocator
      .getCurrentPosition(desiredAccuracy: LocationAccuracy.best, forceAndroidLocationManager: true)
      .then((Position position) {
        setState(() {
          _currentPosition = position;
          _getAddressFromLatLng();
        });
      }).catchError((e) {
        print(e);
      });
  }

  _getAddressFromLatLng() async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(
        _currentPosition.latitude,
        _currentPosition.longitude
      );

      latitude = _currentPosition.latitude;
      longitude = _currentPosition.longitude;

      Placemark place = placemarks[0];

      setState(() {
        _currentAddress = "${place.locality},${place.postalCode}, ${place.country}";
        _location.text=_currentAddress;
      });
    } catch (e) {
      print(e);
    }
  }
}

