import 'dart:async';
//import 'package:BEC_ALUMNI/screens/alumni/signUp.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:go_corona/Screens/admin_model.dart';
import 'package:go_corona/Screens/home_screen.dart';
import 'package:go_corona/Screens/hospital_model.dart';
import 'package:go_corona/Screens/registration.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:progress_state_button/iconed_button.dart';
import 'package:progress_state_button/progress_button.dart';
import '../provider/phone_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class OTPScreen extends StatefulWidget {
  static const routeName = "/otp-screen";
  @override
  _OTPScreenState createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  FocusNode focusNode1 = FocusNode();
  FocusNode focusNode2 = FocusNode();
  FocusNode focusNode3 = FocusNode();
  FocusNode focusNode4 = FocusNode();
  FocusNode focusNode5 = FocusNode();
  FocusNode focusNode6 = FocusNode();
  String code = "";
  bool _isLoading = false;

  var userMsg = "please wait, we are sending OTP";
  String number;

  Box<String> logindata;

  @override
  void initState() {
    super.initState();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
  }

  final scaffoldKey =
      GlobalKey<ScaffoldState>(debugLabel: "scaffold-verify-phone");
  void showBottom(BuildContext ctx, String message) {
    showModalBottomSheet(
        context: ctx,
        builder: (_) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Text('$message'),
              SizedBox(
                height: 10,
              ),
              CircularProgressIndicator(),
              SizedBox(height: 20),
              // ignore: deprecated_member_use
              RaisedButton(
                  child: Text('Enter OTP manually'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  })
            ],
          );
        });
  }

  ButtonState stateOnlyText = ButtonState.idle;
  ButtonState stateTextWithIcon = ButtonState.idle;
  Widget buildTextWithIcon() {
    return ProgressButton.icon(
        maxWidth: MediaQuery.of(context).size.width * .9,
        iconedButtons: {
          ButtonState.idle: IconedButton(
              text: "Verify OTP",
              icon: Icon(Icons.check, color: Colors.white),
              color: Colors.purple.shade500),
          ButtonState.loading:
              IconedButton(text: "Loading", color: Colors.blue.shade700),
          ButtonState.fail: IconedButton(
              text: "failed",
              icon: Icon(Icons.cancel, color: Colors.white),
              color: Colors.red.shade300),
          ButtonState.success: IconedButton(
              text: "success",
              icon: Icon(
                Icons.check_circle,
                color: Colors.white,
              ),
              color: Colors.green.shade400)
        },
        onPressed: onPressedIconWithText,
        state: stateTextWithIcon);
  }

  void onPressedIconWithText() {
    switch (stateTextWithIcon) {
      case ButtonState.idle:
        stateTextWithIcon = ButtonState.loading;
        signIn();
        break;
      case ButtonState.loading:
        break;
      case ButtonState.success:
        stateTextWithIcon = ButtonState.idle;
        break;
      case ButtonState.fail:
        stateTextWithIcon = ButtonState.idle;
        break;
    }
    setState(() {
      stateTextWithIcon = stateTextWithIcon;
    });
  }

  @override
  Widget build(BuildContext context) {
    //  Fetching height & width parameters from the MediaQuery
    //  _logoPadding will be a constant, scaling it according to device's size

    final phoneAuthDataProvider =
        Provider.of<PhoneAuthDataProvider>(context, listen: false);

    // ignore: close_sinks
    StreamController<ErrorAnimationType> errorController =
        StreamController<ErrorAnimationType>();
    // ignore: unused_local_variable
    String currentText;

    phoneAuthDataProvider.setMethods(
      onStarted: onStarted,
      onError: onError,
      onFailed: onFailed,
      onVerified: onVerified,
      onCodeResent: onCodeResent,
      onCodeSent: onCodeSent,
      onAutoRetrievalTimeout: onAutoRetrievalTimeOut,
    );

    return Scaffold(
      resizeToAvoidBottomInset: false,
      key: scaffoldKey,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text("OTP Verification"),
        titleTextStyle: TextStyle(
            fontFamily: "Montserrat Regular", fontSize: 14, color: Colors.blue),
        flexibleSpace: Image(
          image: AssetImage('assets/images/top_header.png'),
          fit: BoxFit.cover,
        ),
        backgroundColor: Colors.transparent,
        centerTitle: true,
      ),
      body: Container(
        width: MediaQuery.of(context).size.width * 0.95,
        height: MediaQuery.of(context).size.height * 0.3,
        margin: EdgeInsets.only(right: 10.0, left: 10.0),
        child: Card(
          elevation: 20,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin:
                          EdgeInsets.symmetric(horizontal: 25, vertical: 20),
                      alignment: Alignment.center,
                      child: Text(
                        '${"Enter OTP".replaceAll("num", (Provider.of<PhoneAuthDataProvider>(context).phone))}',
                        style: TextStyle(
                          fontFamily: 'Segoe UI',
                          fontSize: 22,
                          color: Colors.black87,
                          fontWeight: FontWeight.w700,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    Container(
                      margin:
                          EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                      child: PinCodeTextField(
                        appContext: context,
                        length: 6,
                        obscureText: false,
                        animationType: AnimationType.fade,
                        // textStyle: TextStyle(color: Colors.white),
                        pinTheme: PinTheme(
                          shape: PinCodeFieldShape.box,
                          borderRadius: BorderRadius.circular(5),
                          fieldHeight: 40,
                          fieldWidth: 40,
                          activeFillColor: Colors.white,
                          inactiveFillColor: Colors.white,
                          inactiveColor: Colors.purple[200],
                          selectedFillColor: Colors.white,
                          activeColor: Colors.white,
                          selectedColor: Colors.purple[400],
                        ),
                        animationDuration: Duration(milliseconds: 300),
                        backgroundColor: Colors.transparent,
                        enableActiveFill: true,

                        errorAnimationController: errorController,
                        // controller: textEditingController,

                        onCompleted: (v) {
                          print("Completed");
                          code = v;
                        },
                        onChanged: (value) {
                          print(value);
                          setState(() {
                            currentText = value;
                            code = value;
                          });
                        },
                        beforeTextPaste: (text) {
                          print("Allowing to paste $text");
                          //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                          //but you can show anything you want here, like your pop up saying wrong paste format or etc
                          return true;
                        },
                      ),
                    ),
                    Container(
                      alignment: Alignment.center,
                      child: _isLoading
                          ? Center(child: CircularProgressIndicator())
                          : buildTextWithIcon(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void checkuser() async {
    await Firestore.instance
        .collection("Users")
        .document(number)
        .get()
        .then((value) => {
              if (value.exists)
                {
                  if (value.data['role'] == "user")
                    {
                      logindata.put("emailid", value.data['emailid']),
                      logindata.put("name", value.data['username']),
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          HomeScreen.routeName, (route) => false)
                    }
                  else if (value.data['role'] == "hospital")
                    {
                      logindata.put("emailid", value.data['emailid']),
                      logindata.put("name", value.data['username']),
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          HospitalModel.routeName, (route) => false)
                    }
                  else if (value.data['role'] == "admin")
                    {
                      logindata.put("emailid", value.data['emailid']),
                      logindata.put("name", value.data['username']),
                      Navigator.of(context).pushNamedAndRemoveUntil(
                          AdminModel.routeName, (route) => false)
                    }
                }
              else
                {
                  Navigator.of(context).pushNamedAndRemoveUntil(
                      Registration.routeName, (route) => false)
                }
            });
  }

  _showSnackBar(String text, bool _isSuccess) {
    final snackBar = SnackBar(
      content: Text('$text'),
      duration: Duration(seconds: 2),
      backgroundColor: _isSuccess ? Colors.green : Theme.of(context).errorColor,
    );
    // ignore: deprecated_member_use
    scaffoldKey.currentState.showSnackBar(snackBar);
  }

  signIn() {
    _isLoading = true;
    if (code.length != 6) {
      stateTextWithIcon = ButtonState.idle;
      _isLoading = false;
      _showSnackBar("Invalid OTP", false);
    }
    stateTextWithIcon = ButtonState.idle;
    Provider.of<PhoneAuthDataProvider>(context, listen: false)
        .verifyOTPAndLogin(smsCode: code);
  }

  onStarted() {
    showBottom(context, "we are sending OTP");
  }

  onCodeSent() {
    stateTextWithIcon = ButtonState.idle;
    _showSnackBar("OTP sent", true);
    showBottom(context, "Autofetch OTP");
    setState(() {
      userMsg = "Autofetch OTP";
    });
  }

  onCodeResent() {
    stateTextWithIcon = ButtonState.idle;
    _showSnackBar("OTP resent", true);
    setState(() {
      userMsg = "Resent OTP Recived";
    });
  }

  onVerified() async {
    _isLoading = false;
    stateTextWithIcon = ButtonState.idle;
    _showSnackBar(
        "${Provider.of<PhoneAuthDataProvider>(context, listen: false).message}",
        true);
    await Future.delayed(Duration(seconds: 1));
    checkuser();
    // Navigator.of(context).pushNamedAndRemoveUntil(
    //                     SignUp.routeName, (route) => false);
  }

  onFailed() {
    _isLoading = false;
    stateTextWithIcon = ButtonState.idle;
    _showSnackBar("Phone auth falied", false);
  }

  onError() {
    _isLoading = false;
    stateTextWithIcon = ButtonState.idle;
    _showSnackBar(
        "${"failed"}, ${Provider.of<PhoneAuthDataProvider>(context, listen: false).message}",
        false);
  }

  onAutoRetrievalTimeOut() {
    stateTextWithIcon = ButtonState.idle;
    Navigator.of(context).pop();
    _showSnackBar("Enter OTP manually", false);
    setState(() {
      userMsg = "Already OTP sent";
    });
  }
}
