import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_corona/models/hospitalDetailsModel.dart';

class HospitalrequestsList extends StatefulWidget {
  @override
  _HospitalrequestsListState createState() => _HospitalrequestsListState();
}

class _HospitalrequestsListState extends State<HospitalrequestsList> {
  @override
  Widget build(BuildContext context) {
    // style

    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Requests List"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: StreamBuilder(
                stream: Firestore.instance
                    .collection("Users")
                    .where("status", isEqualTo: "requested")
                    .snapshots(),
                builder: (context, snapShot) {
                  if (snapShot.connectionState == ConnectionState.waiting)
                    return Center(child: CircularProgressIndicator());
                  else {
                    if (snapShot.hasData) {
                      final docSnap = snapShot.data.documents;
                      return docSnap.length <= 0
                          ? Center(child: Text("No Requests Available"))
                          : ListView.builder(
                              padding: const EdgeInsets.only(
                                  left: 25, top: 10, right: 25, bottom: 10),
                              itemCount: docSnap.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  child: Card(
                                      shadowColor: Colors.blueAccent,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      elevation: 4,
                                      child: TextButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Requestdetails(
                                                          hospitalDetailModel:
                                                              HospitalDetailModel(
                                                            address: docSnap[
                                                                    index]
                                                                ['location'],
                                                            emailid:
                                                                docSnap[index]
                                                                    ['emailid'],
                                                            ownername: docSnap[
                                                                    index]
                                                                ['ownername'],
                                                            username: docSnap[
                                                                    index]
                                                                ['username'],
                                                            number:
                                                                docSnap[index]
                                                                    ['number'],
                                                          ),
                                                        )));
                                          },
                                          child: Container(
                                            margin: EdgeInsets.only(
                                                top: 10, left: 10, bottom: 10),
                                            child: Column(children: <Widget>[
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(
                                                        Icons
                                                            .local_hospital_outlined,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' ${docSnap[index]['username']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.person,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Owner Name : ${docSnap[index]['ownername']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.phone,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Phone Number : ${docSnap[index]['number']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                            ]),
                                          ))),
                                );
                              });
                    }
                  }
                })));
  }
}

class Requestdetails extends StatelessWidget {
  final HospitalDetailModel hospitalDetailModel;
  Requestdetails({this.hospitalDetailModel});

  void showInSnackBar(String value, BuildContext context) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop(),
            ),
            title: Text("Details"),
            titleTextStyle: TextStyle(
                fontFamily: "Montserrat Regular",
                fontSize: 14,
                color: Colors.blue),
            flexibleSpace: Image(
              image: AssetImage('assets/images/top_header.png'),
              fit: BoxFit.cover,
            ),
            backgroundColor: Colors.transparent,
            centerTitle: true,
          ),
          body: Container(
            height: 700,
            width: 500,
            margin: EdgeInsets.only(top: 5, left: 10, right: 10, bottom: 10),
            child: ListView(children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 20),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(children: <Widget>[
                            Icon(Icons.local_hospital_outlined,
                                color: Colors.blueGrey),
                            Text(
                              'Hospital Name : ${hospitalDetailModel.username}',
                              style: TextStyle(
                                  fontFamily: 'Hind',
                                  color: Colors.black,
                                  fontSize: 16),
                            ),
                          ])),
                      SizedBox(height: 10),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(children: <Widget>[
                            Icon(Icons.person, color: Colors.blueGrey),
                            Text(
                              'Owner Name : ${hospitalDetailModel.ownername}',
                              style: TextStyle(
                                  fontFamily: 'Hind',
                                  color: Colors.black,
                                  fontSize: 16),
                            ),
                          ])),
                      SizedBox(height: 10),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.location_on, color: Colors.blueGrey),
                                Text(
                                  ' ${hospitalDetailModel.address}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.email, color: Colors.blueGrey),
                                Text(
                                  ' Email-Id :',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                                Container(
                                    child: Expanded(
                                        child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              ' ${hospitalDetailModel.emailid}',
                                              style: TextStyle(
                                                  fontFamily: 'Hind',
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ))))
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.phone, color: Colors.blueGrey),
                                Text(
                                  ' Phone Number : ${hospitalDetailModel.number}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          alignment: Alignment.center,
                          padding:
                              EdgeInsets.only(left: 70, right: 70, bottom: 20),
                          child: Material(
                            elevation: 5,
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(32.0),
                            child: MaterialButton(
                                onPressed: () async {
                                  await Firestore.instance
                                      .collection("Users")
                                      .document(hospitalDetailModel.number)
                                      .updateData({
                                    'status': "accepted",
                                    'acceptedTime': Timestamp.now(),
                                    'icu':false,
                                    'beds':false,
                                    'ventilator':false,
                                    'oxygen':false,
                                    'vaccine':false,
                                    'role':"hospital",
                                  }).then((value) => {
                                            showInSnackBar(
                                                "Accepted successfully",
                                                context)
                                          });
                                  Navigator.pop(context);
                                },
                                minWidth: 200.0,
                                height: 45.0,
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Icon(Icons.check),
                                      SizedBox(width: 10),
                                      Text(
                                        "Accepts",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 20.0),
                                      ),
                                    ])),
                          )),
                      Container(
                          alignment: Alignment.center,
                          padding:
                              EdgeInsets.only(left: 70, right: 70, bottom: 20),
                          child: Material(
                            elevation: 5,
                            color: Colors.red,
                            borderRadius: BorderRadius.circular(32.0),
                            child: MaterialButton(
                                onPressed: ()async {
                                  await Firestore.instance
                                      .collection("Users")
                                      .document(hospitalDetailModel.number)
                                      .updateData({
                                    'status': "rejected",
                                    'rejectedTime': Timestamp.now(),
                                  }).then((value) => {
                                            showInSnackBar(
                                                "Rejected successfully",
                                                context)
                                          });
                                  Navigator.pop(context);
                                },
                                minWidth: 200.0,
                                height: 45.0,
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Icon(Icons.clear),
                                      SizedBox(width: 10),
                                      Text(
                                        "Reject",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 20.0),
                                      ),
                                    ])),
                          ))
                    ]),
              )
            ]),
          ),
        ));
  }
}
