import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_corona/models/requestedBedModel.dart';
import 'package:intl/intl.dart';

class BookedbedsList extends StatefulWidget {
  @override
  _BookedbedsListState createState() => _BookedbedsListState();
}

class _BookedbedsListState extends State<BookedbedsList> {
  @override
  Widget build(BuildContext context) {
    // style

    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Beds Booked List"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: StreamBuilder(
                stream: Firestore.instance
                    .collection("bedBooking")
                    .where("status", isEqualTo: "accepted")
                    .snapshots(),
                builder: (context, snapShot) {
                  if (snapShot.connectionState == ConnectionState.waiting)
                    return Center(child: CircularProgressIndicator());
                  else {
                    if (snapShot.hasData) {
                      final docSnap = snapShot.data.documents;
                      return docSnap.length <= 0
                          ? Center(child: Text("No Booked Beds Available"))
                          : ListView.builder(
                              padding: const EdgeInsets.only(
                                  left: 25, top: 10, right: 25, bottom: 10),
                              itemCount: docSnap.length,
                              itemBuilder: (BuildContext context, int index) {
                                var createdDate = DateTime.parse(docSnap[index]
                                        ['bookingCreatedAt']
                                    .toDate()
                                    .toString());
                                var acceptedDate = DateTime.parse(docSnap[index]
                                        ['acceptedTime']
                                    .toDate()
                                    .toString());
                                return Container(
                                  child: Card(
                                      shadowColor: Colors.blueAccent,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      elevation: 4,
                                      child: TextButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) => Bookedbedsdetails(
                                                        requestedBedDetailModel: RequestedBedDetailModel(
                                                            name: docSnap[index]
                                                                ['name'],
                                                            emailid:
                                                                docSnap[index]
                                                                    ['emailid'],
                                                            number: docSnap[index]
                                                                ['number'],
                                                            aadhar: docSnap[index][
                                                                'aadharNumber'],
                                                            srfId: docSnap[index]
                                                                ['srfId'],
                                                            testedDate: docSnap[
                                                                    index]
                                                                ['testedDate'],
                                                            dateAndTime:
                                                                '${DateFormat('d/MM/y hh:mm a').format(createdDate)}',
                                                            acceptedTime:
                                                                '${DateFormat('d/MM/y hh:mm a').format(acceptedDate)}'))));
                                          },
                                          child: Container(
                                            margin: EdgeInsets.only(
                                                top: 10, left: 10, bottom: 10),
                                            child: Column(children: <Widget>[
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.person,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Name : ${docSnap[index]['name']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.smart_button,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' SRF ID : ${docSnap[index]['srfId']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.date_range,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Tested Date : ${docSnap[index]['testedDate']} ',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.phone,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Phone Number : ${docSnap[index]['number']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                            ]),
                                          ))),
                                );
                              });
                    } else {
                      return Center(child: Text("No Booked Beds Available"));
                    }
                  }
                })));
  }
}

class Bookedbedsdetails extends StatelessWidget {
  final RequestedBedDetailModel requestedBedDetailModel;
  Bookedbedsdetails({this.requestedBedDetailModel});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop(),
            ),
            title: Text("Details"),
            titleTextStyle: TextStyle(
                fontFamily: "Montserrat Regular",
                fontSize: 14,
                color: Colors.blue),
            flexibleSpace: Image(
              image: AssetImage('assets/images/top_header.png'),
              fit: BoxFit.cover,
            ),
            backgroundColor: Colors.transparent,
            centerTitle: true,
          ),
          body: Container(
            height: 700,
            width: 500,
            margin: EdgeInsets.only(top: 5, left: 10, right: 10, bottom: 10),
            child: ListView(children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 20),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(children: <Widget>[
                            Icon(Icons.person, color: Colors.blueGrey),
                            Text(
                              ' Name : ${requestedBedDetailModel.name}',
                              style: TextStyle(
                                  fontFamily: 'Hind',
                                  color: Colors.black,
                                  fontSize: 16),
                            ),
                          ])),
                      SizedBox(height: 10),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.location_on, color: Colors.blueGrey),
                                Text(
                                  ' Bagalkot',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.email, color: Colors.blueGrey),
                                Text(
                                  ' Email-Id :',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                                Container(
                                    child: Expanded(
                                        child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              ' ${requestedBedDetailModel.emailid}',
                                              style: TextStyle(
                                                  fontFamily: 'Hind',
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ))))
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.phone, color: Colors.blueGrey),
                                Text(
                                  ' Phone Number : ${requestedBedDetailModel.number}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.ac_unit, color: Colors.blueGrey),
                                Text(
                                  ' Aadhar Card Number : ',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                                Container(
                                    child: Expanded(
                                        child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              ' ${requestedBedDetailModel.aadhar}',
                                              style: TextStyle(
                                                  fontFamily: 'Hind',
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ))))
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.smart_button,
                                    color: Colors.blueGrey),
                                Text(
                                  ' SRF ID : ',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                                Container(
                                    child: Expanded(
                                        child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              ' SRF-${requestedBedDetailModel.srfId}',
                                              style: TextStyle(
                                                  fontFamily: 'Hind',
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ))))
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.date_range, color: Colors.blueGrey),
                                Text(
                                  ' Tested Date : ${requestedBedDetailModel.testedDate}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.date_range, color: Colors.blueGrey),
                                Text(
                                  ' Accepted Date : ${requestedBedDetailModel.acceptedTime}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          alignment: Alignment.center,
                          padding:
                              EdgeInsets.only(left: 70, right: 70, bottom: 20),
                          child: Material(
                            elevation: 5,
                            color: Colors.green,
                            borderRadius: BorderRadius.circular(32.0),
                            child: MaterialButton(
                                onPressed: () async {
                                  await Firestore.instance
                                      .collection("bedBooking")
                                      .document(requestedBedDetailModel.number)
                                      .updateData({
                                    "status": "discharged",
                                    "discargeTime": Timestamp.now(),
                                  }).then((value) => {
                                            showInSnackBar(
                                                "Discharged", context)
                                          });
                                  Navigator.pop(context);
                                },
                                minWidth: 200.0,
                                height: 45.0,
                                child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    children: <Widget>[
                                      Text(
                                        "Discharge",
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 20.0),
                                      ),
                                    ])),
                          )),
                    ]),
              )
            ]),
          ),
        ));
  }

  void showInSnackBar(String value, BuildContext context) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }
}
