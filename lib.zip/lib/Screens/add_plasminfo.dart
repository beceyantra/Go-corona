import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoder/geocoder.dart' as GeoCoder;
import 'package:hive/hive.dart';

import 'home_screen.dart';

// ignore: camel_case_types
class Addplasminfo extends StatefulWidget {
  @override
  AddplasminfoState createState() => AddplasminfoState();
}

// ignore: camel_case_types
class AddplasminfoState extends State<Addplasminfo> {
  String _setDate;
  String dropdownValue1;
  final _aadhar = TextEditingController();
  final _name = TextEditingController();
  final _srfid = TextEditingController();
  final _testeddate = TextEditingController();
  final _age = TextEditingController();

  final _formFieldKeyaadhar = GlobalKey<FormFieldState>();
  final _formFieldKeyname = GlobalKey<FormFieldState>();
  final _formFieldKeysrfid = GlobalKey<FormFieldState>();
  final _formFieldKeytesteddate = GlobalKey<FormFieldState>();
  final _formFieldKeyage = GlobalKey<FormFieldState>();
  final _formFieldKeyblood = GlobalKey<FormFieldState>();

  String number;
  Box<String> logindata;

  bool _isLoading = false;
  DateTime currentDate = DateTime.now();

  @override
  void initState() {
    // ignore: todo
    // TODO: implement initState
    _getCurrentloc();
    super.initState();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
  }

  double latitude = 00.00000;
  double longitude = 00.00000;
  var coordinates;

  _getCurrentloc() async {
    Position geolocation = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    coordinates =
        new GeoCoder.Coordinates(geolocation.latitude, geolocation.longitude);
    latitude = geolocation.latitude;
    longitude = geolocation.longitude;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Add Plasm"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 14,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Form(
                child: ListView(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyaadhar,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Aadhar Card Number';
                      }
                      return null;
                    },
                    controller: _aadhar,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.ac_unit,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Aadhar Card Number',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyname,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Name';
                      }
                      return null;
                    },
                    controller: _name,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.person,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Name',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeysrfid,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter SRF Id';
                      }
                      return null;
                    },
                    controller: _srfid,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.smart_button,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'SRF ID',
                    ),
                  ),
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                    child: InkWell(
                      onTap: () {
                        _selectDate(context);
                      },
                      child: TextFormField(
                        key: _formFieldKeytesteddate,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter Tested Date';
                          }
                          return null;
                        },
                        enabled: false,
                        controller: _testeddate,
                        keyboardType: TextInputType.datetime,
                        decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.date_range_outlined,
                            color: Colors.brown,
                          ),
                          border: OutlineInputBorder(),
                          labelText: 'Tested Date',
                        ),
                      ),
                    )),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyage,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Age';
                      }
                      return null;
                    },
                    controller: _age,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.date_range,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Age',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: DropdownButtonFormField<String>(
                    value: dropdownValue1,
                    key: _formFieldKeyblood,
                    validator: (value) =>
                        value == null ? 'Please Select Blood Group' : null,
                    decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.water_damage_outlined,
                          color: Colors.brown,
                        ),
                        border: OutlineInputBorder(),
                        labelText: 'Select Blood Group'),
                    onChanged: (String newValue) {
                      setState(() {
                        dropdownValue1 = newValue;
                      });
                    },
                    items: <String>[
                      'AB+',
                      'AB-',
                      'A+',
                      'A-',
                      'B+',
                      'B-',
                      'O+',
                      'O-'
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                _isLoading == true
                    ? Center(child: CircularProgressIndicator())
                    : Container(
                        width: 10,
                        padding: EdgeInsets.only(
                            top: 20, left: 20, right: 20, bottom: 20),
                        child: Material(
                          elevation: 5,
                          color: Colors.lightBlue,
                          borderRadius: BorderRadius.circular(32.0),
                          child: MaterialButton(
                            onPressed: () {
//                  Navigator.push(
//                    context,
//                    MaterialPageRoute(builder: (context) => MyLoginPage()),
//                  );
                              if (_formFieldKeyaadhar.currentState.validate() &&
                                  _formFieldKeyname.currentState.validate() &&
                                  _formFieldKeysrfid.currentState.validate() &&
                                  _formFieldKeytesteddate.currentState
                                      .validate() &&
                                  _formFieldKeyage.currentState.validate()) {
                                _saveform();
                              }
                            },
                            minWidth: 30.0,
                            height: 45.0,
                            child: Text(
                              "Submit",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500, fontSize: 20.0),
                            ),
                          ),
                        ))
              ],
            ))));
  }

  _saveform() async {
    _isLoading = true;
    try {
      await Firestore.instance.collection("Plasma").document(number).setData({
        'plasmaCreatedAt': Timestamp.now(),
        'number': number,
        'name': _name.text,
        'aadharNumber': _aadhar.text,
        'srfId': _srfid.text,
        'testedDate': _testeddate.text,
        'bloodgroup': dropdownValue1,
        'age': _age.text,
        'longitude': longitude,
        'latitude': latitude,
      }).then((value) => {
            _isLoading = false,
            showInSnackBar("Plasma added Completed"),
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => HomeScreen(),
                )),
          });
    } on PlatformException catch (err) {
      var message = 'Error Please try again.. $err';
      _isLoading = false;

      if (err.message != null) {
        message = err.message;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Theme.of(context).errorColor,
        ),
      );
      setState(() {
        _isLoading = false;
      });
    } catch (err) {
      print(err);
      setState(() {
        _isLoading = false;
      });
    }
  }

  void showInSnackBar(String value) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        _testeddate.text = ("${currentDate.toLocal()}".split(' ')[0]);
      });
  }

  clearTextInputs() {
    _aadhar.clear();
    _name.clear();
    _srfid.clear();
    _testeddate.clear();
    _age.clear();
  }
}
