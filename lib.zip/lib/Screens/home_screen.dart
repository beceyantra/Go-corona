import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_corona/Screens/add_hospital.dart';
import 'package:go_corona/Screens/guidlines.dart';
import 'package:go_corona/Screens/plasm_info.dart';
import 'package:go_corona/Screens/bookingDetails.dart';
import 'package:hive/hive.dart';
import 'hospitallist.dart';

class HomeScreen extends StatefulWidget {
    static const routeName = '/homepage';
   @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  void showInSnackBar(String value, BuildContext context) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

Box<String> logindata;
String number,emailid,name;

  @override
  void initState() {
    super.initState();
           logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
    emailid = logindata.get("emailid");
    name = logindata.get("name");

  }
  Widget build(BuildContext context) {
   

    // style
    var cardTextStyle = TextStyle(
        fontFamily: "Montserrat Regular",
        fontSize: 14,
        color: Color.fromRGBO(63, 63, 63, 1));

    return Scaffold(
      body: Stack(
        children: <Widget>[
          Container(
            
            decoration: BoxDecoration(
              image: DecorationImage(
                  alignment: Alignment.topCenter,
                  image: AssetImage('assets/images/top_header.png')),
            ),
          ),
          Container(
            
            decoration: BoxDecoration(
              image: DecorationImage(
                  alignment: Alignment.bottomCenter,
                  image: AssetImage('assets/images/buttom_header.png')),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                children: <Widget>[
                  Container(
                    height: 64,
                    margin: EdgeInsets.only(bottom: 20),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        CircleAvatar(
                          radius: 32,
                          backgroundImage: AssetImage('assets/images/person_icon.jpg'),
                        ),
                        SizedBox(
                          width: 16,
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              "Prakash Bakkannavar",
                              style: TextStyle(
                                  fontFamily: "Montserrat Medium",
                                  color: Colors.white,
                                  fontSize: 20),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                  Expanded(
                    child: GridView.count(
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      primary: false,
                      crossAxisCount: 2,
                      children: <Widget>[
                        Card( 
                          shadowColor: Colors.blueAccent,                                     
                          shape:RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)
                          ),
                          elevation: 4,
                          child: Column(                          
                            mainAxisAlignment: MainAxisAlignment.center,                            
                            children: <Widget>[
                             Container( height: 80,
                               child: ConstrainedBox(constraints: BoxConstraints.expand(),
                                  child: TextButton(onPressed: (){ Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => Hospitallist(),),);},                                 
                                    child: Image.asset('assets/images/hospital.png'),)
                                    ,),                                                                   
                                ),
                                 SizedBox(   //Use of SizedBox
                                    height: 10,
                                  ),
                              Text(                                
                                'Hospital',                                
                                style: cardTextStyle,
                                
                              )  
                            ],
                          ),
                        ),

                        InkWell(
                          onTap: (){
                            Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => Plasminfo(),),);
                          },
                          child: Card(
                            shadowColor: Colors.blueAccent,
                            shape:RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)
                            ),
                            elevation: 4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                    height: 80,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage('assets/images/plasm.png')),
                                    ),
                                  ),
                                   SizedBox(   //Use of SizedBox
                                      height: 10,
                                    ),
                                Text(
                                  'Plasma',
                                  style: cardTextStyle,
                                )
                              ],
                            ),
                          ),
                        ),

                        InkWell(
                          onTap: (){
                             Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => Addhospitalinfo(),),);
                          },
                          child: Card(
                            shadowColor: Colors.blueAccent,
                            shape:RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)
                            ),
                            elevation: 4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                    height: 80,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage('assets/images/vaccine.png')),
                                    ),
                                  ),
                                  SizedBox(   //Use of SizedBox
                                      height: 10,
                                    ),
                                Text(
                                  'Add Hospital',
                                  style: cardTextStyle,
                                )
                              ],
                            ),
                          ),
                        ),

                        InkWell(
                          onTap: (){
                            Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => Guidlines
                                      (),),);
                          },
                          child: Card(
                            shadowColor: Colors.blueAccent,
                            shape:RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)
                            ),
                            elevation: 4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                               Container(
                                    height:80,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage('assets/images/gudilines_of_covide19.png')),
                                    ),
                                  ),
                                  SizedBox(   //Use of SizedBox
                                      height: 10,
                                    ),
                                Text(
                                  'Guidelines',
                                  style: cardTextStyle,
                                )
                              ],
                            ),
                          ),
                        ),

                        InkWell(
                          onTap: (){
                            Navigator.push(
                                      context,
                                      MaterialPageRoute(builder: (context) => BookingDeatils(),),);
                          },
                          child: Card(
                            shadowColor: Colors.blueAccent,
                            shape:RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)
                            ),
                            elevation: 4,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                Container(
                                    height: 80,
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: AssetImage('assets/images/booking_details.jpg')),
                                    ),
                                  ),
                                  SizedBox(   //Use of SizedBox
                                      height: 10,
                                    ),
                                Text(
                                  'Booking Details',
                                  style: cardTextStyle,
                                )
                              ],
                            ),
                          ),
                        ),

                        Card(
                          shadowColor: Colors.blueAccent,
                          shape:RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)
                          ),
                          elevation: 4,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                             Container(
                                  height: 80,
                                  decoration: BoxDecoration(
                                    image: DecorationImage(
                                        image: AssetImage('assets/images/settings.png')),
                                  ),
                                ),
                                SizedBox(   //Use of SizedBox
                                    height: 10,
                                  ),
                              Text(
                                'Settings',
                                style: cardTextStyle,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }


}

class NextPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.lightBlue),
      home: Scaffold(
        appBar: AppBar(
                leading: IconButton(
                  icon: Icon(Icons.arrow_back, color: Colors.white),
                  onPressed: () => Navigator.of(context).pop(),
                ), 
                title: Text("Hospital"),
                titleTextStyle: TextStyle(fontFamily: "Montserrat Regular",
                      fontSize: 14,
                      color: Colors.blue),
                flexibleSpace: Image(
                  image: AssetImage('assets/images/top_header.png'),
                  fit: BoxFit.cover,
                ),
        backgroundColor: Colors.transparent,
                centerTitle: true,
              ),
        body: Text('hii')
      ),
    );
  }
}
