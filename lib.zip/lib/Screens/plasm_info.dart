import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'add_plasminfo.dart';
import 'modifyPlasma.dart';
import 'donators.dart';
import 'hospitallist.dart';

class Plasminfo extends StatefulWidget {
  @override
  PlasminfoState createState() => PlasminfoState();
}

class PlasminfoState extends State<Plasminfo> {
  @override
  Widget build(BuildContext context) {
    var cardTextStyle = TextStyle(
        fontFamily: "Montserrat Regular",
        fontSize: 14,
        color: Color.fromRGBO(63, 63, 63, 1));

    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Plasm Information"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Container(
                margin: EdgeInsets.only(top: 30),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Container(
                        height: 150,
                        width: 150,
                        child: Card(
                            shadowColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            elevation: 4,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Addplasminfo()));
                              },
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Icon(Icons.add, color: Colors.black),
                                    SizedBox(width: 10),
                                    Text(
                                      'Add   ',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 20.0),
                                    ),
                                  ]),
                            ))),
                    Container(
                        margin: EdgeInsets.only(top: 10),
                        height: 150,
                        width: 150,
                        child: Card(
                            shadowColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            elevation: 4,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Donators()));
                              },
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Icon(Icons.donut_large,
                                        color: Colors.black),
                                    SizedBox(width: 10),
                                    Text(
                                      'Donators',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 20.0),
                                    ),
                                  ]),
                            ))),
                    Container(
                        margin: EdgeInsets.only(top: 10),
                        height: 150,
                        width: 150,
                        child: Card(
                            shadowColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            elevation: 4,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Modifyplasminfo()));
                              },
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Icon(Icons.mode_edit, color: Colors.black),
                                    SizedBox(width: 10),
                                    Text(
                                      'Modify',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 20.0),
                                    ),
                                  ]),
                            )))
                  ],
                ))));
  }
}
