import 'package:account_picker/account_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';

import 'home_screen.dart';

class Registration extends StatefulWidget {
  static const routeName = '/register';
  @override
  _RegistrationState createState() => _RegistrationState();
}

class _RegistrationState extends State<Registration> {
  bool _isLoading = false;
  String dropdownValue, dropdownValue1;
  final _name = TextEditingController();
  final emailController = TextEditingController();
  final _aadhar = TextEditingController();
  final _age = TextEditingController();

  Box<String> logindata;
  String number;

  bool emailTap = false;
  bool isEmailValid = false;

  final _formFieldKeyname = GlobalKey<FormFieldState>();
  final _formFieldKeyemail = GlobalKey<FormFieldState>();
  final _formFieldKeyaadhar = GlobalKey<FormFieldState>();
  final _formFieldKeyage = GlobalKey<FormFieldState>();
  final _formFieldKeygender = GlobalKey<FormFieldState>();
  final _formFieldKeyblood = GlobalKey<FormFieldState>();

  @override
  void initState() {
    super.initState();
    // _getloc();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
  }

  // bool _isexit = true;

  // @override
  // void didChangeDependencies() {
  //   if (_isexit) {
  //     super.didChangeDependencies();
  //     // load();
  //   }
  //   _isexit = false;
  // }

  // void load() async {
  //   // ignore: deprecated_member_use
  //   requestPermission().then((value) {
  //     setState(() {
  //       locationPermission = value;
  //     });
  //   });
  //   // ignore: deprecated_member_use
  //   locationPermission = await checkPermission();
  // }

  // _getloc() {
  //   try {
  //     Geolocator.getCurrentPosition(
  //             desiredAccuracy: LocationAccuracy.best,
  //             forceAndroidLocationManager: true)
  //         .then((Position position) {
  //       setState(() {
  //         _currentPosition = position;
  //         _getAddressFromLatLng();
  //       });
  //     }).catchError((e) {
  //       print(e);
  //     });
  //   } catch (err) {
  //     print(err + "okok");
  //   }
  // }

  // _getAddressFromLatLng() async {
  //   try {
  //     List<Placemark> placemarks = await placemarkFromCoordinates(
  //         _currentPosition.latitude, _currentPosition.longitude);

  //     Placemark place = placemarks[0];

  //     setState(() {
  //       _currentAddress =
  //           "${place.locality}, ${place.postalCode}, ${place.country}";
  //     });
  //   } catch (e) {
  //     print(e);
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              title: Text("Registration"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 14,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Form(
                child: ListView(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyname,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Full Name';
                      }
                      return null;
                    },
                    controller: _name,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.person,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Full Name',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyemail,
                    validator: (value) {
                      if (value.length > 1) if (!EmailValidator.validate(value))
                        return 'Please Enter Email Id';
                      return null;
                    },
                    onTap: () async {
                      if (!emailTap) {
                        emailTap = true;
                        print("Email tap 2 $emailTap");
                        EmailResult emailResult =
                            await AccountPicker.emailHint();
                        print(emailResult);
                        setState(() {
                          emailController.text = emailResult.email;

                          if (emailResult != null) isEmailValid = true;
                        });
                      }
                    },
                    onChanged: (value) {
                      // namecontroller.text=value;

                      if (!EmailValidator.validate(value)) {
                        setState(() {
                          isEmailValid = false;
                        });
                      } else {
                        setState(() {
                          isEmailValid = true;
                        });
                      }
                    },
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.email,
                        color: Colors.brown,
                      ),
                      suffixIcon: emailController.text.length < 1
                          ? null
                          : isEmailValid
                              ? Icon(Icons.check_circle)
                              : Icon(
                                  Icons.error,
                                  color: Colors.red,
                                ),
                      errorStyle: TextStyle(color: Colors.amber),
                      labelText: 'Email ID',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyaadhar,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Aadhara Card Number';
                      }
                      return null;
                    },
                    controller: _aadhar,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.ac_unit,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Aadhara Card Number',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: DropdownButtonFormField<String>(
                    value: dropdownValue,
                    key: _formFieldKeygender,
                    validator: (value) =>
                        value == null ? 'Please Select Gender' : null,
                    decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.person_add_alt_1_sharp,
                          color: Colors.brown,
                        ),
                        border: OutlineInputBorder(),
                        labelText: 'Select Gender'),
                    onChanged: (String newValue) {
                      setState(() {
                        dropdownValue = newValue;
                      });
                    },
                    items: <String>['Male', 'Femal', 'Others']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: DropdownButtonFormField<String>(
                    value: dropdownValue1,
                    key: _formFieldKeyblood,
                    validator: (value) =>
                        value == null ? 'Please Select Blood Group' : null,
                    decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.water_damage_outlined,
                          color: Colors.brown,
                        ),
                        border: OutlineInputBorder(),
                        labelText: 'Select Blood Group'),
                    onChanged: (String newValue) {
                      setState(() {
                        dropdownValue1 = newValue;
                      });
                    },
                    items: <String>[
                      'AB+',
                      'AB-',
                      'A+',
                      'A-',
                      'B+',
                      'B-',
                      'O+',
                      'O-'
                    ].map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyage,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Age';
                      }
                      return null;
                    },
                    controller: _age,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.date_range,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Age',
                    ),
                  ),
                ),
                Container(
                    padding: EdgeInsets.only(
                        top: 20, left: 20, right: 20, bottom: 20),
                    child: Material(
                      elevation: 5,
                      color: Colors.lightBlue,
                      borderRadius: BorderRadius.circular(32.0),
                      child: _isLoading == true
                          ? Center(child: CircularProgressIndicator())
                          : MaterialButton(
                              onPressed: () {
                                if (_formFieldKeyname.currentState.validate() &&
                                    _formFieldKeyemail.currentState
                                        .validate() &&
                                    _formFieldKeyaadhar.currentState
                                        .validate() &&
                                    _formFieldKeyage.currentState.validate() &&
                                    _formFieldKeygender.currentState
                                        .validate() &&
                                    _formFieldKeyblood.currentState
                                        .validate()) {
                                  // _sendDataToSecondScreen(context);
                                  _savedata();
                                }
                              },
                              minWidth: 200.0,
                              height: 45.0,
                              child: Text(
                                "Register",
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 20.0),
                              ),
                            ),
                    ))
              ],
            ))));
  }

  void showInSnackBar(String value) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  void _savedata() async {
    _isLoading = true;
    try {
      await Firestore.instance.collection("Users").document(number).setData({
        'createdAt': Timestamp.now(),
        'username': _name.text,
        'emailid': emailController.text,
        'aadharnumber': _aadhar.text,
        'gender': dropdownValue,
        'bloodgroup': dropdownValue1,
        'age': _age.text,
        'role': "user"
      }).then((value) => {
            _isLoading = false,
            showInSnackBar("Registration Completed"),
            logindata.put("emailid", emailController.text),
            logindata.put("name", _name.text),
            _sendDataToSecondScreen(context)
          });
    } on PlatformException catch (err) {
      var message = 'Registration Error Please try again.. $err';

      if (err.message != null) {
        message = err.message;
      }

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: Theme.of(context).errorColor,
        ),
      );
      setState(() {
        _isLoading = false;
      });
    } catch (err) {
      print(err);
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _sendDataToSecondScreen(BuildContext context) {
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => HomeScreen(),
        ));
  }

  clearTextInputs() {
    _name.clear();
    emailController.clear();
    _aadhar.clear();
    _age.clear();
  }
}
