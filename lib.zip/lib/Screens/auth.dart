import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import '../provider/phone_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:progress_state_button/iconed_button.dart';
import 'package:progress_state_button/progress_button.dart';
import 'package:provider/provider.dart';
import './otp_screen.dart';
import 'package:flutter/rendering.dart';

// Authentication using phone number
class AuthScreen extends StatefulWidget {
  static const routeName = "\auth-screen";
  @override
  _AuthScreenState createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _form = GlobalKey<FormState>();

  String countryCode;
  _showErrorSnackbar(String message) {
    // ignore: deprecated_member_use
    scaffoldKey.currentState.showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  bool valid = false;
  ButtonState stateOnlyText = ButtonState.idle;
  ButtonState stateTextWithIcon = ButtonState.idle;
  Widget buildTextWithIcon() {
    return ProgressButton.icon(
        maxWidth: MediaQuery.of(context).size.width * .9,
        iconedButtons: {
          ButtonState.idle: IconedButton(
              text: "Send Code",
              icon: Icon(Icons.send, color: Colors.white),
              color: Colors.lightBlue),
          ButtonState.loading:
              IconedButton(text: "Loading", color: Colors.blue.shade700),
          ButtonState.fail: IconedButton(
              text: "failed",
              icon: Icon(Icons.cancel, color: Colors.white),
              color: Colors.red.shade300),
          ButtonState.success: IconedButton(
              text: "success",
              icon: Icon(
                Icons.check_circle,
                color: Colors.white,
              ),
              color: Colors.green.shade400)
        },
        onPressed: onPressedIconWithText,
        state: stateTextWithIcon);
  }

  void onPressedIconWithText() async {
    switch (stateTextWithIcon) {
      case ButtonState.idle:
        stateTextWithIcon = ButtonState.loading;
        if (valid) {
          startPhoneAuth();
        } else {
          _showErrorSnackbar('oops incorrect number');
        }

        break;
      case ButtonState.loading:
        break;
      case ButtonState.success:
        stateTextWithIcon = ButtonState.idle;
        break;
      case ButtonState.fail:
        stateTextWithIcon = ButtonState.idle;
        break;
    }
    setState(() {
      stateTextWithIcon = stateTextWithIcon;
    });
  }

  void checkuser() async {}

  Box<String> logindata;

  @override
  void initState() {
    stateTextWithIcon = ButtonState.idle;
    logindata = Hive.box<String>("loginData");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    stateTextWithIcon = ButtonState.idle;
    return Scaffold(
        key: scaffoldKey,
        appBar: AppBar(
          title: Text("Phone Authentication"),
          titleTextStyle: TextStyle(
              fontFamily: "Montserrat Regular",
              fontSize: 14,
              color: Colors.blue),
          flexibleSpace: Image(
            image: AssetImage('assets/images/top_header.png'),
            fit: BoxFit.cover,
          ),
          backgroundColor: Colors.transparent,
          centerTitle: true,
        ),
        body: Stack(
          children: <Widget>[
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              child: Card(
                elevation: 10.0,
                margin: EdgeInsets.only(right: 10.0, left: 10.0),
                child: Form(
                  key: _form,
                  child: Center(
                    child: Container(
                      margin: EdgeInsets.only(right: 5.0, left: 2.0),
                      child: IntlPhoneField(
                        autoValidate: true,
                        onSaved: (newValue) {},
                        validator: (value) {
                          // RegExp regExp = new RegExp(r'^[0-9]{10}');
                          if (value.length < 10) {
                            return "Incorrect number";
                          }
                          if (!valid) return "InCorrect";
                          return null;
                        },
                        controller: Provider.of<PhoneAuthDataProvider>(context,
                                listen: false)
                            .phoneNumberController,
                        decoration: InputDecoration(
                          suffixIcon: valid
                              ? Icon(Icons.check_circle, color: Colors.green)
                              : Icon(Icons.error, color: Colors.amber),
                          prefixIcon: Icon(Icons.phone),
                          //  labelText:  AppLocalizations.of(context).translate('phoneNum'),
                          hintText: "phone number",
                          labelStyle: TextStyle(color: Colors.black),
                          fillColor: Colors.white,
                          filled: true,
                          border: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.black, width: 1),
                              borderRadius: BorderRadius.circular(10)),
                          focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.black, width: 1),
                              borderRadius: BorderRadius.circular(10)),
                          enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.black, width: 1),
                              borderRadius: BorderRadius.circular(10)),
                          disabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.black, width: 1),
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        initialCountryCode: 'IN',
                        onChanged: (phone) {
                          print(phone.completeNumber);
                          countryCode = phone.countryCode;
                          RegExp regExp = new RegExp(r'^[0-9]{10}');
                          if (phone.number.length < 10) {
                            setState(() {
                              valid = false;
                            });
                          } else if (!regExp.hasMatch(phone.number)) {
                            setState(() {
                              valid = false;
                            });
                          } else {
                            setState(() {
                              valid = true;
                            });
                          }
                        },
                        onSubmitted: (phone) {
                          print(phone);
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
                alignment: Alignment.topCenter,
                padding: EdgeInsets.only(
                    top: MediaQuery.of(context).size.height * .27,
                    right: 80.0,
                    left: 80.0),
                child: buildTextWithIcon())
            // Positioned(
            //   left: 80,
            //   right: 80,
            //   child: buildTextWithIcon(),
            // ),
          ],
        ));
  }

  startPhoneAuth() async {
    final phoneAuthDataProvider =
        Provider.of<PhoneAuthDataProvider>(context, listen: false);
    phoneAuthDataProvider.loading = true;

    bool validPhone = await phoneAuthDataProvider.instantiate(
        dialCode: countryCode,
        onCodeSent: () {
          stateTextWithIcon = ButtonState.idle;
          setState(() {
            logindata.put(
                "number",
                Provider.of<PhoneAuthDataProvider>(context, listen: false)
                    .phoneNumberController
                    .text);
          });
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => OTPScreen()));
        },
        onFailed: () {
          stateTextWithIcon = ButtonState.idle;
          _showErrorSnackbar(phoneAuthDataProvider.message);
        },
        onError: () {
          stateTextWithIcon = ButtonState.idle;
          _showErrorSnackbar(phoneAuthDataProvider.message);
        });
    //if(valid)
    if (!validPhone && !valid) {
      phoneAuthDataProvider.loading = false;
      _showErrorSnackbar("oops incorrect number");
      stateTextWithIcon = ButtonState.idle;
      return;
    }
  }
}
