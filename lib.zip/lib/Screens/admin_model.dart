import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_corona/Screens/userlist.dart';

import 'admin_hospitallist.dart';
import 'hospital_requests.dart';

class AdminModel extends StatefulWidget {
  static const routeName = '/admin';
  @override
  _AdminModelState createState() => _AdminModelState();
}

class _AdminModelState extends State<AdminModel> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              title: Text("Admin Model"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Container(
                margin: EdgeInsets.only(top: 30),
                alignment: Alignment.center,
                child: Column(
                  children: <Widget>[
                    Container(
                        height: 150,
                        width: 150,
                        child: Card(
                            shadowColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            elevation: 4,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            HospitalrequestsList()));
                              },
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      'Requests',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 20.0),
                                    ),
                                  ]),
                            ))),
                    Container(
                        margin: EdgeInsets.only(top: 10),
                        height: 150,
                        width: 150,
                        child: Card(
                            shadowColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            elevation: 4,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            Adminhospitallist()));
                              },
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      'Hospital List',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 20.0),
                                    ),
                                  ]),
                            ))),
                    Container(
                        margin: EdgeInsets.only(top: 10),
                        height: 150,
                        width: 150,
                        child: Card(
                            shadowColor: Colors.blueAccent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20)),
                            elevation: 4,
                            child: TextButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Userlist()));
                              },
                              child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      'Users List',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 20.0),
                                    ),
                                  ]),
                            ))),
                  ],
                ))));
  }
}
