import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:hive/hive.dart';
import 'package:geocoder/geocoder.dart' as GeoCoder;

import 'home_screen.dart';

// ignore: camel_case_types
class Book_bed_form extends StatefulWidget {
  @override
  _Book_bed_formState createState() => _Book_bed_formState();
}

// ignore: camel_case_types
class _Book_bed_formState extends State<Book_bed_form> {
  // ignore: unused_field
  String _setDate;
  final _aadhar = TextEditingController();
  final _name = TextEditingController();
  final _srfid = TextEditingController();
  final _testeddate = TextEditingController();
  final _age = TextEditingController();

  final _formFieldKeyaadhar = GlobalKey<FormFieldState>();
  final _formFieldKeyname = GlobalKey<FormFieldState>();
  final _formFieldKeysrfid = GlobalKey<FormFieldState>();
  final _formFieldKeytesteddate = GlobalKey<FormFieldState>();
  final _formFieldKeyage = GlobalKey<FormFieldState>();

  DateTime currentDate = DateTime.now();
  bool agree = false;

  bool _isLoading = false;

  String number, emailid;
  Box<String> logindata;

  @override
  void initState() {
    _getCurrentloc();
    super.initState();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
    emailid = logindata.get("emailid");
  }

  double latitude = 00.00000;
  double longitude = 00.00000;
  var coordinates;

  _getCurrentloc() async {
    Position geolocation = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    coordinates =
        new GeoCoder.Coordinates(geolocation.latitude, geolocation.longitude);
    latitude = geolocation.latitude;
    longitude = geolocation.longitude;
  }

  _saveform() async {
    if (agree) {
      _isLoading = true;
      try {
        await Firestore.instance
            .collection("bedBooking")
            .document(number)
            .setData({
          'bookingCreatedAt': Timestamp.now(),
          'number': number,
          'name': _name.text,
          'aadharNumber': _aadhar.text,
          'srfId': _srfid.text,
          'testedDate': _testeddate.text,
          'age': _age.text,
          'longitude': longitude,
          'latitude': latitude,
          'TermsAndCondition': agree,
          "status": "requested",
          "emailid": emailid,
        }).then((value) => {
                  _isLoading = false,
                  showInSnackBar(
                      "Booking Request Sent To Hospital Please Verify by visiting hospital "),
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomeScreen(),
                      )),
                });
      } on PlatformException catch (err) {
        var message = 'Error Please try again.. $err';
        _isLoading = false;

        if (err.message != null) {
          message = err.message;
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(message),
            backgroundColor: Theme.of(context).errorColor,
          ),
        );
        setState(() {
          _isLoading = false;
        });
      } catch (err) {
        print(err);
        setState(() {
          _isLoading = false;
        });
      }
    } else {
      showInSnackBar("Please agree for terms and conditions");
    }
  }

  void showInSnackBar(String value) {
    ScaffoldMessenger.of(context)
        .showSnackBar(new SnackBar(content: new Text(value)));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Bed Booking"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 14,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Form(
                child: ListView(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyaadhar,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Aadhar Card Number';
                      }
                      return null;
                    },
                    controller: _aadhar,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.ac_unit,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Aadhar Card Number',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyname,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Name';
                      }
                      return null;
                    },
                    controller: _name,
                    keyboardType: TextInputType.name,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.person,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Name',
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeysrfid,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter SRF Id';
                      }
                      return null;
                    },
                    controller: _srfid,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.smart_button,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'SRF ID',
                    ),
                  ),
                ),
                Container(
                    padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                    child: InkWell(
                      onTap: () {
                        _selectDate(context);
                      },
                      child: TextFormField(
                        key: _formFieldKeytesteddate,
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter Tested Date';
                          }
                          return null;
                        },
                        enabled: false,
                        controller: _testeddate,
                        onSaved: (String val) {
                          _setDate = val;
                        },
                        keyboardType: TextInputType.datetime,
                        decoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.date_range_outlined,
                            color: Colors.brown,
                          ),
                          border: OutlineInputBorder(),
                          labelText: 'Tested Date',
                        ),
                      ),
                    )),
                Container(
                  padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                  child: TextFormField(
                    key: _formFieldKeyage,
                    validator: (value) {
                      if (value.isEmpty) {
                        return 'Please enter Age';
                      }
                      return null;
                    },
                    controller: _age,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      prefixIcon: Icon(
                        Icons.date_range,
                        color: Colors.brown,
                      ),
                      border: OutlineInputBorder(),
                      labelText: 'Age',
                    ),
                  ),
                ),
                Card(
                    margin: EdgeInsets.only(
                        top: 20, left: 20, right: 20, bottom: 10),
                    shadowColor: Colors.blueAccent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    elevation: 4,
                    child: Container(
                      margin: EdgeInsets.only(left: 10, right: 10),
                      height: 200,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Padding(padding: EdgeInsets.all(5.0)),
                          Text(
                            'Terms and Conditions',
                            style: TextStyle(
                                decoration: TextDecoration.underline,
                                fontWeight: FontWeight.w500,
                                fontSize: 16.0,
                                fontFamily: 'Hind'),
                          ),
                          Text(
                            '-Please admit within 5 hour otherwise it will be rejected',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 16.0,
                                fontFamily: 'Hind'),
                          ),
                          Text(
                            '-Use sanitizer',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 16.0,
                                fontFamily: 'Hind'),
                          ),
                          Text(
                            '-Use Mask ',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 16.0,
                                fontFamily: 'Hind'),
                          ),
                          Text(
                            '-Keep at least 1 feet from others ',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 16.0,
                                fontFamily: 'Hind'),
                          ),
                        ],
                      ),
                    )),
                Container(
                    width: 10,
                    padding: EdgeInsets.only(left: 20, right: 20, bottom: 10),
                    child: Row(children: <Widget>[
                      Padding(padding: EdgeInsets.all(5.0)),
                      Checkbox(
                        value: agree,
                        onChanged: (value) {
                          setState(() {
                            agree = value;
                          });
                        },
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text(
                        ' agree',
                      )
                    ])),
                _isLoading == true
                    ? Center(child: CircularProgressIndicator())
                    : Container(
                        width: 10,
                        padding: EdgeInsets.only(
                            top: 10, left: 20, right: 20, bottom: 20),
                        child: Material(
                          elevation: 5,
                          color: Colors.lightBlue,
                          borderRadius: BorderRadius.circular(32.0),
                          child: MaterialButton(
                            onPressed: () {
//                  Navigator.push(
//                    context,
//                    MaterialPageRoute(builder: (context) => MyLoginPage()),
//                  );
                              if (_formFieldKeyaadhar.currentState.validate() &&
                                  _formFieldKeyname.currentState.validate() &&
                                  _formFieldKeysrfid.currentState.validate() &&
                                  _formFieldKeytesteddate.currentState
                                      .validate() &&
                                  _formFieldKeyage.currentState.validate() &&
                                  agree) {
                                _saveform();
                              }
                            },
                            minWidth: 30.0,
                            height: 45.0,
                            child: Text(
                              "Book",
                              style: TextStyle(
                                  fontWeight: FontWeight.w500, fontSize: 20.0),
                            ),
                          ),
                        ))
              ],
            ))));
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        _testeddate.text = ("${currentDate.toLocal()}".split(' ')[0]);
      });
  }

  clearTextInputs() {
    _aadhar.clear();
    _name.clear();
    _srfid.clear();
    _testeddate.clear();
    _age.clear();
  }
}
