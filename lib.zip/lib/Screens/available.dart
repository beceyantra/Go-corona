import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:hive/hive.dart';

class Available extends StatefulWidget {
  @override
  _AvailableState createState() => _AvailableState();
}

class _AvailableState extends State<Available> {
  bool isSwitched1 = false;
  bool isSwitched2 = false;
  bool isSwitched3 = false;
  bool isSwitched4 = false;
  bool isSwitched5 = false;
  var textValue1 = 'Not-Available';
  var textValue2 = 'Not-Available';
  var textValue3 = 'Not-Available';
  var textValue4 = 'Not-Available';
  var textValue5 = 'Not-Available';

  String number;
  Box<String> logindata;

  @override
  void initState() {
    super.initState();
    logindata = Hive.box<String>("loginData");
    number = logindata.get("number");
  }

  // void _loaddata() async {
  //   try {
  //     await Firestore.instance
  //         .collection("Users")
  //         .document(number)
  //         .get()
  //         .then((value) => {
  //               if (value.exists)
  //                 {
  //                   print(" ok  ${value.data['beds']}"),
  //                   isSwitched1 = value.data['beds'],
  //                   isSwitched2 = value.data['icu'],
  //                   isSwitched3 = value.data['ventilator'],
  //                   isSwitched4 = value.data['oxygen'],
  //                   isSwitched5 = value.data['vaccine'],
  //                 }
  //             });
  //   } catch (error) {}
  // }

  Future<void> _change(BuildContext context) async {
    try {
      await Firestore.instance.collection("Users").document(number).updateData({
        "beds": isSwitched1,
        "icu": isSwitched2,
        "ventilator": isSwitched3,
        "oxygen": isSwitched4,
        "vaccine": isSwitched5,
      });
    } catch (err) {}
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop(),
            ),
            title: Text("Availables"),
            titleTextStyle: TextStyle(
                fontFamily: "Montserrat Regular",
                fontSize: 14,
                color: Colors.blue),
            flexibleSpace: Image(
              image: AssetImage('assets/images/top_header.png'),
              fit: BoxFit.cover,
            ),
            backgroundColor: Colors.transparent,
            centerTitle: true,
          ),
          body: StreamBuilder(
              stream: Firestore.instance
                  .collection("Users")
                  .document(number)
                  .snapshots(),
              builder: (context, snapshot) {
                isSwitched1 = snapshot.data['beds'];
                isSwitched2 = snapshot.data['icu'];
                isSwitched3 = snapshot.data['ventilator'];
                isSwitched4 = snapshot.data['oxygen'];
                isSwitched5 = snapshot.data['vaccine'];
                return Container(
                  height: 700,
                  width: 500,
                  margin:
                      EdgeInsets.only(top: 5, left: 20, right: 20, bottom: 10),
                  child: ListView(children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(top: 20, bottom: 20),
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Container(
                                height: 50,
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.grey, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(2.0, 2.0),
                                      )
                                    ]),
                                child: Row(children: <Widget>[
                                  Icon(Icons.king_bed, color: Colors.blueGrey),
                                  Text(
                                    ' Bed : ',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      width: 150,
                                      child: Text(
                                        isSwitched1
                                            ? 'Available'
                                            : "Not-Available",
                                        style: isSwitched1
                                            ? TextStyle(
                                                color: Colors.green,
                                                fontFamily: 'Hind',
                                                fontSize: 16)
                                            : TextStyle(
                                                color: Colors.red,
                                                fontFamily: 'Hind',
                                                fontSize: 16),
                                      )),
                                  SizedBox(width: 10),
                                  Container(
                                      alignment: Alignment.centerRight,
                                      child: Switch(
                                        onChanged: (value) {
                                          setState(() {
                                            isSwitched1 = value;
                                            _change(context);
                                            print(isSwitched1);
                                          });
                                        },
                                        value: isSwitched1,
                                        activeColor: Colors.white,
                                        activeTrackColor: Colors.blue,
                                      ))
                                ])),
                            SizedBox(height: 12),
                            Container(
                                height: 50,
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.grey, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(2.0, 2.0),
                                      )
                                    ]),
                                child: Row(children: <Widget>[
                                  Icon(Icons.picture_in_picture,
                                      color: Colors.blueGrey),
                                  Text(
                                    ' ICU : ',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      width: 150,
                                      child: Text(
                                        isSwitched2
                                            ? 'Available'
                                            : "Not-Available",
                                        style: isSwitched2
                                            ? TextStyle(
                                                color: Colors.green,
                                                fontFamily: 'Hind',
                                                fontSize: 16)
                                            : TextStyle(
                                                color: Colors.red,
                                                fontFamily: 'Hind',
                                                fontSize: 16),
                                      )),
                                  SizedBox(width: 10),
                                  Container(
                                      alignment: Alignment.centerRight,
                                      child: Switch(
                                        onChanged: (value) {
                                          setState(() {
                                            isSwitched2 = value;
                                            _change(context);
                                            print(isSwitched2);
                                          });
                                        },
                                        value: isSwitched2,
                                        activeColor: Colors.white,
                                        activeTrackColor: Colors.blue,
                                      ))
                                ])),
                            SizedBox(height: 12),
                            Container(
                                height: 50,
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.grey, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(2.0, 2.0),
                                      )
                                    ]),
                                child: Row(children: <Widget>[
                                  Icon(Icons.vignette_rounded,
                                      color: Colors.blueGrey),
                                  Text(
                                    ' Ventilators : ',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      width: 100,
                                      child: Text(
                                        isSwitched3
                                            ? 'Available'
                                            : "Not-Available",
                                        style: isSwitched3
                                            ? TextStyle(
                                                color: Colors.green,
                                                fontFamily: 'Hind',
                                                fontSize: 16)
                                            : TextStyle(
                                                color: Colors.red,
                                                fontFamily: 'Hind',
                                                fontSize: 16),
                                      )),
                                  SizedBox(width: 10),
                                  Container(
                                      alignment: Alignment.centerRight,
                                      child: Switch(
                                        onChanged: (value) {
                                          setState(() {
                                            isSwitched3 = value;
                                            _change(context);
                                            print(isSwitched3);
                                          });
                                        },
                                        value: isSwitched3,
                                        activeColor: Colors.white,
                                        activeTrackColor: Colors.blue,
                                      ))
                                ])),
                            SizedBox(height: 12),
                            Container(
                                height: 50,
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.grey, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(2.0, 2.0),
                                      )
                                    ]),
                                child: Row(children: <Widget>[
                                  Icon(Icons.outbox, color: Colors.blueGrey),
                                  Text(
                                    ' Oxigen : ',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      width: 128,
                                      child: Text(
                                        isSwitched4
                                            ? 'Available'
                                            : "Not-Available",
                                        style: isSwitched4
                                            ? TextStyle(
                                                color: Colors.green,
                                                fontFamily: 'Hind',
                                                fontSize: 16)
                                            : TextStyle(
                                                color: Colors.red,
                                                fontFamily: 'Hind',
                                                fontSize: 16),
                                      )),
                                  SizedBox(width: 10),
                                  Container(
                                      alignment: Alignment.centerRight,
                                      child: Switch(
                                        onChanged: (value) {
                                          setState(() {
                                            isSwitched4 = value;
                                            _change(context);
                                            print(isSwitched4);
                                          });
                                        },
                                        value: isSwitched4,
                                        activeColor: Colors.white,
                                        activeTrackColor: Colors.blue,
                                      ))
                                ])),
                            SizedBox(height: 12),
                            Container(
                                height: 50,
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: Colors.grey, width: 1),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.white,
                                        offset: Offset(2.0, 2.0),
                                      )
                                    ]),
                                child: Row(children: <Widget>[
                                  Icon(Icons.local_hospital,
                                      color: Colors.blueGrey),
                                  Text(
                                    ' Vaccine : ',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      width: 125,
                                      child: Text(
                                        isSwitched5
                                            ? 'Available'
                                            : "Not-Available",
                                        style: isSwitched5
                                            ? TextStyle(
                                                color: Colors.green,
                                                fontFamily: 'Hind',
                                                fontSize: 16)
                                            : TextStyle(
                                                color: Colors.red,
                                                fontFamily: 'Hind',
                                                fontSize: 16),
                                      )),
                                  SizedBox(width: 10),
                                  Container(
                                      alignment: Alignment.centerRight,
                                      child: Switch(
                                        onChanged: (value) {
                                          setState(() {
                                            isSwitched5 = value;
                                            _change(context);
                                            print(isSwitched5);
                                          });
                                        },
                                        value: isSwitched5,
                                        activeColor: Colors.white,
                                        activeTrackColor: Colors.blue,
                                      ))
                                ])),
                          ]),
                    )
                  ]),
                );
              }),
        ));
  }
}
