import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_corona/models/hospitalDetailsModel.dart';

class Adminhospitallist extends StatefulWidget {
  @override
  _AdminhospitallistState createState() => _AdminhospitallistState();
}

class _AdminhospitallistState extends State<Adminhospitallist> {
  final List<String> img = <String>[
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg',
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg',
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg',
    'hospital1.jpg',
    'hospital2.jpg',
    'hospital3.jpg'
  ];

  @override
  Widget build(BuildContext context) {
    // style

    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Hospital List"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: StreamBuilder(
                stream: Firestore.instance
                    .collection("Users")
                    .where("role", isEqualTo: "hospital")
                    .where("status", isEqualTo: "accepted")
                    .snapshots(),
                builder: (context, snapShot) {
                  if (snapShot.connectionState == ConnectionState.waiting)
                    return Center(child: CircularProgressIndicator());
                  else {
                    if (snapShot.hasData) {
                      final docSnap = snapShot.data.documents;
                      return docSnap.length <= 0
                          ? Center(child: Text("No Requests Available"))
                          : ListView.builder(
                              padding: const EdgeInsets.all(8),
                              itemCount: docSnap.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Container(
                                  height: 80,
                                  margin: EdgeInsets.only(top: 5),
                                  child: Card(
                                    shadowColor: Colors.blueAccent,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(20)),
                                    elevation: 4,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: <Widget>[
                                        TextButton(
                                          onPressed: () {},
                                          child: CircleAvatar(
                                            radius: 32,
                                            backgroundImage: AssetImage(
                                                'assets/images/${img[index]}'),
                                          ),
                                        ),
                                        SizedBox(
                                          width: 16,
                                        ),
                                        Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: <Widget>[
                                            Text(
                                              ' ${docSnap[index]['username']}',
                                              style: TextStyle(
                                                  fontFamily:
                                                      "Montserrat Medium",
                                                  color: Colors.black,
                                                  fontSize: 14),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          width: 16,
                                        ),
                                        IconButton(
                                          icon: Icon(Icons.play_arrow_outlined,
                                              color: Colors.black),
                                          onPressed: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => Hdetails(
                                                  hospitalDetailModel:
                                                      HospitalDetailModel(
                                                    address: docSnap[index]
                                                        ['location'],
                                                    emailid: docSnap[index]
                                                        ['emailid'],
                                                    ownername: docSnap[index]
                                                        ['ownername'],
                                                    username: docSnap[index]
                                                        ['username'],
                                                    number: docSnap[index]
                                                        ['number'],
                                                  ),
                                                ),
                                              ),
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              });
                    }
                  }
                })));
  }
}

class Hdetails extends StatelessWidget {
  final HospitalDetailModel hospitalDetailModel;
  Hdetails({this.hospitalDetailModel});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Hospital Datails"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 14,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: Container(
              height: 700,
              width: 500,
              margin: EdgeInsets.only(top: 5, left: 10, right: 10, bottom: 10),
              child: Card(
                shadowColor: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
                elevation: 4,
                child: ListView(children: <Widget>[
                  Container(
                      padding: EdgeInsets.only(top: 20, bottom: 20),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            CircleAvatar(
                              radius: 100,
                              backgroundImage:
                                  AssetImage('assets/images/hospital1.jpg'),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text(
                              '${hospitalDetailModel.username}',
                              style: TextStyle(
                                  fontFamily: 'Hind',
                                  color: Colors.black,
                                  fontSize: 16),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Divider(
                              color: Colors.black,
                            ),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 20, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.person),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Owner Name: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      '${hospitalDetailModel.ownername}',
                                      style: TextStyle(
                                          fontFamily: 'Hind', fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.home),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Addrees: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      '${hospitalDetailModel.address}',
                                      style: TextStyle(
                                          fontFamily: 'Hind', fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(
                                  children: <Widget>[
                                    Icon(Icons.phone_android),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      'Phone Number: ',
                                      style: TextStyle(
                                          fontFamily: 'Hind',
                                          color: Colors.black,
                                          fontSize: 15),
                                    ),
                                    Text(
                                      '${hospitalDetailModel.number}',
                                      style: TextStyle(
                                          fontFamily: 'Hind', fontSize: 15),
                                    ),
                                  ],
                                )),
                            Container(
                                padding: EdgeInsets.only(
                                    top: 15, left: 10, right: 10),
                                width: 500,
                                child: Row(children: <Widget>[
                                  Icon(Icons.email, color: Colors.black),
                                  Text(
                                    ' Email-Id :',
                                    style: TextStyle(
                                        fontFamily: 'Hind',
                                        color: Colors.black,
                                        fontSize: 16),
                                  ),
                                  Container(
                                      child: Expanded(
                                          child: SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Text(
                                                ' ${hospitalDetailModel.emailid}',
                                                style: TextStyle(
                                                    fontFamily: 'Hind',
                                                    color: Colors.black,
                                                    fontSize: 16),
                                              ))))
                                ])),
                          ])),
                ]),
              ),
            )));
  }
}
