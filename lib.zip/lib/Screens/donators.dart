import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoder/geocoder.dart' as GeoCoder;
import 'dart:math' as Math;

import 'package:go_corona/models/donatorsModel.dart';

class Donators extends StatefulWidget {
  @override
  _DonatorsState createState() => _DonatorsState();
}

class _DonatorsState extends State<Donators> {
  double latitude = 00.00000;
  double longitude = 00.00000;
  var coordinates;

  _getCurrentloc() async {
    Position geolocation = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    coordinates =
        new GeoCoder.Coordinates(geolocation.latitude, geolocation.longitude);
    latitude = geolocation.latitude;
    longitude = geolocation.longitude;
  }

  Future<void> _getAddressFromLatLng(double lat, double long) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, long);

      Placemark place = placemarks[0];
      var _location;
      setState(() {
        var _currentAddress =
            "${place.locality},${place.postalCode}, ${place.country}";
        _location = _currentAddress;
      });
      return _location;
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    _getCurrentloc();
    super.initState();
  }

  double getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2 - lat1); // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(deg2rad(lat1)) *
            Math.cos(deg2rad(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in km
    return d;
  }

  double deg2rad(deg) {
    return deg * (Math.pi / 180);
  }

  @override
  Widget build(BuildContext context) {
    // style

    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                icon: Icon(Icons.arrow_back, color: Colors.black),
                onPressed: () => Navigator.of(context).pop(),
              ),
              title: Text("Donators List"),
              titleTextStyle: TextStyle(
                  fontFamily: "Montserrat Regular",
                  fontSize: 16,
                  color: Colors.blue),
              flexibleSpace: Image(
                image: AssetImage('assets/images/top_header.png'),
                fit: BoxFit.cover,
              ),
              backgroundColor: Colors.transparent,
              centerTitle: true,
            ),
            body: StreamBuilder(
                stream: Firestore.instance.collection("Plasma").snapshots(),
                builder: (context, snapShot) {
                  if (snapShot.connectionState == ConnectionState.waiting)
                    return Center(child: CircularProgressIndicator());
                  else {
                    if (snapShot.hasData) {
                      final docSnap = snapShot.data.documents;

                      return docSnap.length <= 0
                          ? Center(child: Text("No Plasma Available"))
                          : ListView.builder(
                              padding: const EdgeInsets.only(
                                  left: 25, top: 10, right: 25, bottom: 10),
                              itemCount: docSnap.length,
                              itemBuilder: (BuildContext context, int index) {
                                double latitude1 = docSnap[index]['latitude'];
                                double longitude1 = docSnap[index]['longitude'];
                                var dist = getDistanceFromLatLonInKm(
                                    latitude, longitude, latitude1, longitude1);
                                
                                // var address = _getAddressFromLatLng(
                                //     latitude1, longitude1);
                                return 
                                dist>50?
                                Container()
                                 :
                                 Container(
                                  child: Card(
                                      shadowColor: Colors.blueAccent,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(20)),
                                      elevation: 4,
                                      child: TextButton(
                                          onPressed: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Donatorsdetails(
                                                          donatorsModel: DonatorsModel(
                                                            id: docSnap[index].documentID,
                                                            name: docSnap[index]['name'],
                                                            srfId: docSnap[index]['srfId'],
                                                            aadharNumber: docSnap[index]['aadharNumber'],
                                                            age: docSnap[index]['age'],
                                                            bloodgroup: docSnap[index]['bloodgroup'],
                                                            number: docSnap[index]['number'],
                                                            plasmaCreatedAt: docSnap[index]['plasmaCreatedAt'],
                                                            testedDate: docSnap[index]['testedDate'],
                                                            dist: dist,                                                            
                                                          )
                                                        )));
                                          },
                                          child: Container(
                                            margin: EdgeInsets.only(
                                                top: 10, left: 10, bottom: 10),
                                            child: Column(children: <Widget>[
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.person,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Name : ${docSnap[index]['name']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.directions_walk,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Distance : $dist KM',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                              SizedBox(height: 10),
                                              Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Icon(Icons.phone,
                                                        color: Colors.brown),
                                                    Text(
                                                      ' Phone Number : ${docSnap[index]['number']}',
                                                      style: TextStyle(
                                                          fontFamily: 'Hind',
                                                          color: Colors.black,
                                                          fontSize: 15),
                                                    ),
                                                  ]),
                                            ]),
                                          ))),
                                );
                              });
                    }else{
                     return Center(child: Text("No Plasma Available"));
                    }
                  }
                })));
  }
}

class Donatorsdetails extends StatelessWidget {
  
  final DonatorsModel donatorsModel;
  Donatorsdetails({this.donatorsModel});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(primarySwatch: Colors.lightBlue),
        home: Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop(),
            ),
            title: Text("Donator Datails"),
            titleTextStyle: TextStyle(
                fontFamily: "Montserrat Regular",
                fontSize: 14,
                color: Colors.blue),
            flexibleSpace: Image(
              image: AssetImage('assets/images/top_header.png'),
              fit: BoxFit.cover,
            ),
            backgroundColor: Colors.transparent,
            centerTitle: true,
          ),
          body: Container(
            height: 700,
            width: 500,
            margin: EdgeInsets.only(top: 5, left: 10, right: 10, bottom: 10),
            child: ListView(children: <Widget>[
              Container(
                padding: EdgeInsets.only(top: 20, bottom: 20),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(children: <Widget>[
                            Icon(Icons.person, color: Colors.blueGrey),
                            Text(
                              ' Name : ${donatorsModel.name}',
                              style: TextStyle(
                                  fontFamily: 'Hind',
                                  color: Colors.black,
                                  fontSize: 16),
                            ),
                          ])),
                      SizedBox(height: 10),
                     
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.directions_walk,
                                    color: Colors.blueGrey),
                                Text(
                                  ' Distance : ${donatorsModel.dist} KM',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      // Container(
                      //     height: 50,
                      //     padding: EdgeInsets.all(5),
                      //     decoration: BoxDecoration(
                      //         border: Border.all(color: Colors.grey, width: 1),
                      //         boxShadow: [
                      //           BoxShadow(
                      //             color: Colors.white,
                      //             offset: Offset(2.0, 2.0),
                      //           )
                      //         ]),
                      //     child: Row(
                      //         mainAxisAlignment: MainAxisAlignment.start,
                      //         crossAxisAlignment: CrossAxisAlignment.center,
                      //         children: <Widget>[
                      //           Icon(Icons.email, color: Colors.blueGrey),
                      //           Text(
                      //             ' Email-Id :',
                      //             style: TextStyle(
                      //                 fontFamily: 'Hind',
                      //                 color: Colors.black,
                      //                 fontSize: 16),
                      //           ),
                      //           Container(
                      //               child: Expanded(
                      //                   child: SingleChildScrollView(
                      //                       scrollDirection: Axis.horizontal,
                      //                       child: Text(
                      //                         ' {}',
                      //                         style: TextStyle(
                      //                             fontFamily: 'Hind',
                      //                             color: Colors.black,
                      //                             fontSize: 16),
                      //                       ))))
                      //         ])),
                      // SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.phone, color: Colors.blueGrey),
                                Text(
                                  ' Phone Number : ${donatorsModel.number}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.ac_unit, color: Colors.blueGrey),
                                Text(
                                  ' Aadhar Card Number : ',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                                Container(
                                    child: Expanded(
                                        child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              ' ${donatorsModel.aadharNumber}',
                                              style: TextStyle(
                                                  fontFamily: 'Hind',
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ))))
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.smart_button,
                                    color: Colors.blueGrey),
                                Text(
                                  ' SRF ID : ',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                                Container(
                                    child: Expanded(
                                        child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              ' ${donatorsModel.srfId}',
                                              style: TextStyle(
                                                  fontFamily: 'Hind',
                                                  color: Colors.black,
                                                  fontSize: 16),
                                            ))))
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.date_range, color: Colors.blueGrey),
                                Text(
                                  ' Tested Date : ${donatorsModel.testedDate}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.water_damage_outlined,
                                    color: Colors.blueGrey),
                                Text(
                                  ' Blood Group : ${donatorsModel.bloodgroup}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                      SizedBox(height: 12),
                      Container(
                          height: 50,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey, width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.white,
                                  offset: Offset(2.0, 2.0),
                                )
                              ]),
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: <Widget>[
                                Icon(Icons.date_range, color: Colors.blueGrey),
                                Text(
                                  ' age : ${donatorsModel.age}',
                                  style: TextStyle(
                                      fontFamily: 'Hind',
                                      color: Colors.black,
                                      fontSize: 16),
                                ),
                              ])),
                    ]),
              )
            ]),
          ),
        ));
  }
}
