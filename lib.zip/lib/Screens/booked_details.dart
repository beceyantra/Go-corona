import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import 'booked_beds.dart';
import 'dischargelist.dart';

class BookedDetails extends StatefulWidget {
  @override
  _BookedDetailsState createState() =>_BookedDetailsState();
  }
  


class _BookedDetailsState extends State<BookedDetails> {


 

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.lightBlue),
                home: Scaffold(
                  appBar: AppBar(    
                            leading: IconButton(
                          icon: Icon(Icons.arrow_back, color: Colors.black),
                          onPressed: () => Navigator.of(context).pop(),
                             ),
                          title: Text("Booked Details"),
                          titleTextStyle: TextStyle(fontFamily: "Montserrat Regular",
                                fontSize: 16,
                                color: Colors.blue),
                          flexibleSpace: Image(
                            image: AssetImage('assets/images/top_header.png'),
                            fit: BoxFit.cover,
                          ),
                  backgroundColor: Colors.transparent,
                          centerTitle: true,
                        ),
      body:  Container(
        margin: EdgeInsets.only(top:30),
        alignment: Alignment.center,
                    child: Column(
                      
                    children: <Widget>[
                      Container(
                        
                        height: 150,
                        width: 150,
                         child: Card( 
                          shadowColor: Colors.blueAccent,                                     
                          shape:RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)
                          ),
                          elevation: 4,
                          child: TextButton(
                            
                        onPressed: () {  Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>BookedbedsList()
                                )); },                           
                          child: Row(
                           mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[  
                                             
                        
                                                
                         Text('Booked Beds',
                        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20.0),),
                      ]),
                      )
                      )
                       ),
                       
                        Container(
                        margin: EdgeInsets.only(top:10),
                        height: 150,
                        width: 150,
                         child: Card( 
                          shadowColor: Colors.blueAccent,                                     
                          shape:RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20)
                          ),
                          elevation: 4,
                          child: TextButton(
                            
                        onPressed: () { Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>DishargeList()
                                ));  },                           
                          child: Row(
                           mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[  
                                              
                         
                                             
                         Text('Discharge',
                        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 20.0),),
                      ]),
                      )
                      )
                       ),
                       
                        ],
                    )
                    )
                  
                )
                );
                
    
    
    }
    }