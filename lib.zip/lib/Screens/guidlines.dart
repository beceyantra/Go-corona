import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/material.dart';  

import 'package:carousel_slider/carousel_slider.dart';

  

class Guidlines extends StatefulWidget {
  @override
  _GuidlinesState createState() =>  _GuidlinesState();
    }
  
class _GuidlinesState extends State<Guidlines> {  
   double _current = 0;
  
  @override  
 
@override
Widget build(BuildContext context) {
	return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.lightBlue),
      home: Scaffold(
        appBar: AppBar(
                leading: IconButton(
                  icon: Icon(Icons.arrow_back, color: Colors.black),
                  onPressed: () => Navigator.of(context).pop(),
                ), 
                title: Text("Guidlines"),
                titleTextStyle: TextStyle(fontFamily: "Montserrat Regular",
                      fontSize: 14,
                      color: Colors.blue),
                flexibleSpace: Image(
                  image: AssetImage('assets/images/top_header.png'),
                  fit: BoxFit.cover,
                ),
        backgroundColor: Colors.transparent,
                centerTitle: true,
              ),
	body: ListView(
		children: [
		CarouselSlider(
			items: [
				
				//1st Image of Slider
				Container(
         
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g1.jpg'),
					fit: BoxFit.fill,
					),
				),
				),
				
				//2nd Image of Slider
				Container(
           
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g2.jpg'),
					fit: BoxFit.fill,
					),
				),
				),
				
				//3rd Image of Slider
				Container(
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image:AssetImage('assets/images/g3.jpg'),
					fit: BoxFit.fill,
					),
				),
				),
				
				//4th Image of Slider
				Container(
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g4.jpg'),
					fit: BoxFit.fill,
					),
				),
				),
				
				//5th Image of Slider
				Container(
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g5.jpg'),
					fit: BoxFit.fill,
					),
				),
				),
        
        	//6th Image of Slider
				Container(
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g6.jpg'),
					fit: BoxFit.fill,
					),
				),
				),

        	//7th Image of Slider
				Container(
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g7.jpg'),
					fit: BoxFit.fill,
					),
				),
				),

        	//8th Image of Slider
				Container(
				margin: EdgeInsets.all(6.0),
				decoration: BoxDecoration(
					borderRadius: BorderRadius.circular(8.0),
					image: DecorationImage(
					image: AssetImage('assets/images/g8.jpg'),
					fit: BoxFit.fill,
					),
				),
				),

		],
			
			//Slider Container properties
			options: CarouselOptions(
				height: 550.0,
				enlargeCenterPage: true,
				autoPlay: false,
				aspectRatio: 16 / 9,
				autoPlayCurve: Curves.fastOutSlowIn,
				enableInfiniteScroll: true,
        autoPlayAnimationDuration: Duration(milliseconds: 800),
				viewportFraction: 0.8,
        onPageChanged: (index,reason){
          setState(() {
                  _current = index.toDouble();
                });
        },
        
                
                
                
              ),
        
            ),
            DotsIndicator(
          dotsCount:8,
          position:_current,
        )
            ],
          ),
          
        
          ));
        }
        }
        
        
